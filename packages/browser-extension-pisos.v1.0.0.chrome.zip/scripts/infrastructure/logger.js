/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
!function() {
var exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
__webpack_unused_export__ = void 0;
class Logger {
    context;
    constructor(context) {
        this.context = context;
    }
    log(message, data) {
        const timestamp = new Date().toISOString();
        const prefix = `[${timestamp}][${this.context}]`;
        if (data) {
            console.log(`${prefix} ${message}`, data);
        }
        else {
            console.log(`${prefix} ${message}`);
        }
    }
    error(message, error) {
        const timestamp = new Date().toISOString();
        const prefix = `[${timestamp}][${this.context}][ERROR]`;
        if (error) {
            console.error(`${prefix} ${message}`, error);
        }
        else {
            console.error(`${prefix} ${message}`);
        }
    }
}
__webpack_unused_export__ = Logger;

}();
/******/ })()
;
//# sourceMappingURL=logger.js.map