/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 294:
/***/ (function(__unused_webpack_module, exports) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ConfigService = void 0;
class ConfigService {
    static STORAGE_KEY = 'investmentAnalysisConfig';
    static DEFAULT_CONFIG = {
        expenseConfig: {
            propertyManagementMonthly: 150,
            insuranceMonthly: 50,
            propertyTaxMonthly: 100,
            communityFees: 60,
            vacancyMaintenanceRate: 0.05,
            maintenanceContingencyRate: 0.01,
        },
        mortgageConfig: {
            loanToValueRatio: 0.8,
            managementFeesRate: 0.1,
            interestRate: 2.45,
        },
        profitabilityThresholds: {
            excellent: 6,
            good: 4,
            fair: 2,
        },
        displayOptions: {
            showBadges: true,
            showModal: true,
            showLoadingStates: true,
        },
    };
    async getConfig() {
        try {
            const result = await chrome.storage.sync.get(ConfigService.STORAGE_KEY);
            const storedConfig = result[ConfigService.STORAGE_KEY];
            if (!storedConfig) {
                return ConfigService.DEFAULT_CONFIG;
            }
            const migratedConfig = this.migrateOldConfig(storedConfig);
            return { ...ConfigService.DEFAULT_CONFIG, ...migratedConfig };
        }
        catch (error) {
            console.error('Error loading config:', error);
            return ConfigService.DEFAULT_CONFIG;
        }
    }
    migrateOldConfig(config) {
        if (config.expenseConfig) {
            if (config.expenseConfig.communityFeesWithGarage && !config.expenseConfig.communityFees) {
                const avgCommunity = Math.round(((config.expenseConfig.communityFeesWithGarage || 80) +
                    (config.expenseConfig.communityFeesWithoutGarage || 40)) /
                    2);
                config.expenseConfig.communityFees = avgCommunity;
                delete config.expenseConfig.communityFeesWithGarage;
                delete config.expenseConfig.communityFeesWithoutGarage;
            }
        }
        return config;
    }
    async updateConfig(partialConfig) {
        try {
            const currentConfig = await this.getConfig();
            const newConfig = { ...currentConfig, ...partialConfig };
            await chrome.storage.sync.set({
                [ConfigService.STORAGE_KEY]: newConfig,
            });
        }
        catch (error) {
            console.error('Error saving config:', error);
            throw error;
        }
    }
    async resetToDefaults() {
        try {
            await chrome.storage.sync.set({
                [ConfigService.STORAGE_KEY]: ConfigService.DEFAULT_CONFIG,
            });
        }
        catch (error) {
            console.error('Error resetting config:', error);
            throw error;
        }
    }
}
exports.ConfigService = ConfigService;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
!function() {
var exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
__webpack_unused_export__ = void 0;
const config_service_1 = __webpack_require__(294);
class InvestmentUIRenderer {
    logger;
    languageService;
    configService;
    userConfig;
    constructor(logger, languageService) {
        this.logger = logger;
        this.languageService = languageService;
        this.configService = new config_service_1.ConfigService();
    }
    async renderBadge(property, analysis) {
        if (!this.userConfig) {
            this.userConfig = await this.configService.getConfig();
        }
        if (!this.userConfig.displayOptions.showBadges) {
            return;
        }
        const propertyElement = this.findPropertyElement(property.id);
        if (!propertyElement) {
            this.logger.error(`Property element not found for ID: ${property.id}`);
            return;
        }
        this.removeBadge(property);
        const analysisButton = this.createAnalysisButton(property, analysis);
        const descriptionContainer = propertyElement.querySelector('.item-description');
        if (descriptionContainer) {
            descriptionContainer.parentNode?.insertBefore(analysisButton, descriptionContainer.nextSibling);
            this.logger.log(`Investment analysis button rendered for property ${property.id}: ${analysis.recommendation}`);
        }
        else {
            this.logger.error(`Description container not found for property ${property.id}`);
        }
    }
    async renderLoadingBadge(property) {
        if (!this.userConfig) {
            this.userConfig = await this.configService.getConfig();
        }
        if (!this.userConfig.displayOptions.showLoadingStates) {
            return;
        }
        const propertyElement = this.findPropertyElement(property.id);
        if (!propertyElement)
            return;
        this.removeBadge(property);
        const badge = document.createElement('div');
        badge.className = 'investment-badge investment-badge--loading';
        badge.setAttribute('data-property-id', property.id);
        badge.innerHTML = `
      <div class="investment-badge__content">
        <div class="loading-spinner"></div>
        <div class="investment-badge__text">${this.languageService.getMessage('analyzing')}</div>
      </div>
    `;
        const multimediaContainer = propertyElement.querySelector('.item-multimedia');
        if (multimediaContainer) {
            multimediaContainer.appendChild(badge);
            this.logger.log(`Loading badge rendered for property ${property.id}`);
        }
    }
    renderNoDataBadge(property) {
        const propertyElement = this.findPropertyElement(property.id);
        if (!propertyElement)
            return;
        this.removeBadge(property);
        const badge = document.createElement('div');
        badge.className = 'investment-badge investment-badge--no-data';
        badge.setAttribute('data-property-id', property.id);
        badge.innerHTML = `
      <div class="investment-badge__content">
        <div class="investment-badge__icon">📊</div>
        <div class="investment-badge__text">${this.languageService.getMessage('noRentalData')}</div>
      </div>
    `;
        const multimediaContainer = propertyElement.querySelector('.item-multimedia');
        if (multimediaContainer) {
            multimediaContainer.appendChild(badge);
            this.logger.log(`No data badge rendered for property ${property.id}`);
        }
    }
    renderErrorBadge(property) {
        const propertyElement = this.findPropertyElement(property.id);
        if (!propertyElement)
            return;
        this.removeBadge(property);
        const badge = document.createElement('div');
        badge.className = 'investment-badge investment-badge--error';
        badge.setAttribute('data-property-id', property.id);
        badge.innerHTML = `
      <div class="investment-badge__content">
        <div class="investment-badge__icon">⚠️</div>
        <div class="investment-badge__text">${this.languageService.getMessage('analysisError')}</div>
      </div>
    `;
        const multimediaContainer = propertyElement.querySelector('.item-multimedia');
        if (multimediaContainer) {
            multimediaContainer.appendChild(badge);
            this.logger.log(`Error badge rendered for property ${property.id}`);
        }
    }
    removeBadge(property) {
        const existingElements = document.querySelectorAll(`[data-property-id="${property.id}"]`);
        existingElements.forEach((element) => element.remove());
    }
    findPropertyElement(propertyId) {
        return document.querySelector(`article.item[data-element-id="${propertyId}"]`);
    }
    createAnalysisButton(property, analysis) {
        const buttonContainer = document.createElement('div');
        buttonContainer.className = 'investment-analysis-container';
        buttonContainer.setAttribute('data-property-id', analysis.propertyId);
        const delay = this.getStaggeredDelay(analysis.propertyId);
        buttonContainer.style.animationDelay = `${delay}ms`;
        const button = document.createElement('button');
        button.className = `investment-analysis-button investment-analysis-button--${analysis.recommendation}`;
        button.innerHTML = `
      <div class="investment-analysis-button__content">
        <div class="investment-analysis-button__yield">
          <span class="investment-analysis-button__yield-label">${this.languageService.getMessage('netProfitability')}</span>
          <span class="investment-analysis-button__yield-value">${analysis.netYield}%</span>
        </div>
        <div class="investment-analysis-button__recommendation">
          ${this.getRecommendationText(analysis.recommendation)}
        </div>
        <div class="investment-analysis-button__icon">📊</div>
      </div>
    `;
        button.addEventListener('click', async (e) => {
            e.preventDefault();
            e.stopPropagation();
            this.addRippleEffect(button);
            if (!this.userConfig) {
                this.userConfig = await this.configService.getConfig();
            }
            if (this.userConfig.displayOptions.showModal) {
                this.openAnalysisModal(property, analysis);
                this.logger.log(`Investment modal opened for property ${property.id}`);
            }
        });
        buttonContainer.appendChild(button);
        return buttonContainer;
    }
    getStaggeredDelay(propertyId) {
        const hash = propertyId.split('').reduce((a, b) => {
            a = ((a << 5) - a) + b.charCodeAt(0);
            return a & a;
        }, 0);
        return Math.abs(hash % 200);
    }
    addRippleEffect(button) {
        button.classList.add('clicked');
        setTimeout(() => {
            button.classList.remove('clicked');
        }, 600);
    }
    openAnalysisModal(property, analysis) {
        const modalRenderer = new ModalRenderer(this.logger, this.languageService);
        modalRenderer.openModal(property, analysis);
    }
    getRecommendationText(recommendation) {
        switch (recommendation) {
            case 'excellent':
                return this.languageService.getMessage('excellentInvestment');
            case 'good':
                return this.languageService.getMessage('goodInvestment');
            case 'fair':
                return this.languageService.getMessage('regularInvestment');
            case 'poor':
                return this.languageService.getMessage('badInvestment');
            default:
                return this.languageService.getMessage('unknownInvestment');
        }
    }
}
__webpack_unused_export__ = InvestmentUIRenderer;
class ModalRenderer {
    logger;
    languageService;
    constructor(logger, languageService) {
        this.logger = logger;
        this.languageService = languageService;
    }
    openModal(property, analysis) {
        const existingModal = document.querySelector('.investment-modal-overlay');
        if (existingModal) {
            existingModal.remove();
        }
        const modalOverlay = document.createElement('div');
        modalOverlay.className = 'investment-modal-overlay';
        const modal = document.createElement('div');
        modal.className = 'investment-modal';
        modal.innerHTML = this.createModalContent(property, analysis);
        modalOverlay.appendChild(modal);
        document.body.appendChild(modalOverlay);
        this.addEventListeners(modal, modalOverlay);
    }
    createModalContent(property, analysis) {
        return `
      <div class="investment-modal__header">
        <h3 class="investment-modal__title">${this.languageService.getMessage('investmentAnalysisTitle')}</h3>
        <button class="investment-modal__close">×</button>
      </div>
      
      <div class="investment-modal__content">
        <div class="investment-modal__property-info">
          <h4>${property.title}</h4>
          <p class="investment-modal__property-details">
            ${property.rooms ? property.rooms + this.languageService.getMessage('roomsSuffix') : ''} 
            ${property.size ? property.size + this.languageService.getMessage('sizeSuffix') : ''}
            ${property.floor ? ' • ' + property.floor : ''}
          </p>
        </div>

        <div class="investment-modal__analysis">
          <div class="investment-modal__recommendation investment-modal__recommendation--${analysis.recommendation}">
            <div class="investment-modal__recommendation-text">
              ${this.getRecommendationText(analysis.recommendation)}
            </div>
            <div class="investment-modal__recommendation-yield">
              ${this.languageService.getMessage('netProfitability')} ${analysis.netYield}%
            </div>
          </div>

          <div class="investment-modal__details-grid">
            <div class="investment-modal__detail-item">
              <span class="investment-modal__label">${this.languageService.getMessage('purchasePrice')}</span>
              <span class="investment-modal__value">${this.languageService.formatCurrency(analysis.purchasePrice)}</span>
            </div>
            
            <div class="investment-modal__detail-item">
              <span class="investment-modal__label">${this.languageService.getMessage('monthlyRentalEstimate')}</span>
              <span class="investment-modal__value">${this.languageService.formatCurrency(analysis.estimatedRent)}</span>
            </div>
            
            <div class="investment-modal__detail-item">
              <span class="investment-modal__label">${this.languageService.getMessage('monthlyExpensesEstimate')}</span>
              <span class="investment-modal__value">${this.languageService.formatCurrency(analysis.monthlyExpenses)}</span>
            </div>
            
            <div class="investment-modal__divider"></div>
            
            <div class="investment-modal__detail-item">
              <span class="investment-modal__label">${this.languageService.getMessage('grossAnnualProfitability')}</span>
              <span class="investment-modal__value">${analysis.grossYield}%</span>
            </div>
            
            <div class="investment-modal__detail-item investment-modal__detail-item--highlight">
              <span class="investment-modal__label">${this.languageService.getMessage('netAnnualProfitability')}</span>
              <span class="investment-modal__value">${analysis.netYield}%</span>
            </div>
            
            <div class="investment-modal__risk investment-modal__risk--${analysis.riskLevel}">
              <div class="investment-modal__risk-dot"></div>
              <span>${this.languageService.getMessage('riskLevel')}${analysis.riskLevel.toUpperCase()}</span>
            </div>
          </div>
        </div>
      </div>
    `;
    }
    addEventListeners(modal, modalOverlay) {
        const closeButton = modal.querySelector('.investment-modal__close');
        closeButton?.addEventListener('click', () => {
            modalOverlay.remove();
        });
        modalOverlay.addEventListener('click', (e) => {
            if (e.target === modalOverlay) {
                modalOverlay.remove();
            }
        });
        const handleEscape = (e) => {
            if (e.key === 'Escape') {
                modalOverlay.remove();
                document.removeEventListener('keydown', handleEscape);
            }
        };
        document.addEventListener('keydown', handleEscape);
    }
    getRecommendationText(recommendation) {
        switch (recommendation) {
            case 'excellent':
                return this.languageService.getMessage('excellentInvestment');
            case 'good':
                return this.languageService.getMessage('goodInvestment');
            case 'fair':
                return this.languageService.getMessage('regularInvestment');
            case 'poor':
                return this.languageService.getMessage('badInvestment');
            default:
                return this.languageService.getMessage('unknownInvestment');
        }
    }
}

}();
/******/ })()
;
//# sourceMappingURL=ui-renderer.js.map