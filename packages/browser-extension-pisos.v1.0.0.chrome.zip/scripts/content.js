/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 16:
/***/ (function(__unused_webpack_module, exports) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.RentalDataAnalyzer = void 0;
class RentalDataAnalyzer {
    logger;
    propertyExtractor;
    cacheService;
    errorHandler;
    constructor(logger, propertyExtractor, cacheService, errorHandler) {
        this.logger = logger;
        this.propertyExtractor = propertyExtractor;
        this.cacheService = cacheService;
        this.errorHandler = errorHandler;
    }
    async fetchRentalData(rentalUrl) {
        const cacheKey = this.createCacheKey(rentalUrl);
        const cachedData = await this.cacheService.get(cacheKey);
        if (cachedData) {
            return cachedData;
        }
        return this.fetchWithRetry(rentalUrl, cacheKey, 1);
    }
    async fetchWithRetry(rentalUrl, cacheKey, attempt) {
        const context = {
            operation: 'fetchRentalData',
            url: rentalUrl,
        };
        try {
            this.logger.log(`Fetching rental data (attempt ${attempt}): ${rentalUrl}`);
            const response = await fetch(rentalUrl, {
                method: 'GET',
                headers: {
                    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'es-ES,es;q=0.5',
                    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
                },
            });
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: Failed to fetch rental data`);
            }
            const html = await response.text();
            const data = this.parseRentalDataFromHtml(html);
            if (data) {
                await this.cacheService.set(cacheKey, data);
            }
            return data;
        }
        catch (error) {
            this.errorHandler.handleError(error, context);
            if (this.errorHandler.shouldRetry(error, attempt)) {
                const delay = this.errorHandler.getRetryDelay(attempt);
                this.logger.log(`Retrying in ${delay}ms (attempt ${attempt + 1})`);
                await this.delay(delay);
                return this.fetchWithRetry(rentalUrl, cacheKey, attempt + 1);
            }
            return null;
        }
    }
    createCacheKey(url) {
        try {
            const urlObj = new URL(url);
            return `${urlObj.pathname}${urlObj.search}`;
        }
        catch {
            return url;
        }
    }
    delay(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
    parseRentalDataFromHtml(html) {
        try {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const properties = this.propertyExtractor.extractPropertiesFromDocument(doc);
            if (properties.length === 0) {
                this.logger.log('No rental properties found in response');
                return null;
            }
            const prices = properties
                .map((p) => p.price)
                .filter((price) => price > 0)
                .sort((a, b) => a - b);
            if (prices.length === 0) {
                this.logger.log('No valid prices found in rental properties');
                return null;
            }
            const averagePrice = prices.reduce((sum, price) => sum + price, 0) / prices.length;
            const minPrice = prices[0];
            const maxPrice = prices[prices.length - 1];
            this.logger.log(`Rental analysis: ${prices.length} properties, avg: ${averagePrice}€`);
            return {
                averagePrice: Math.round(averagePrice),
                minPrice,
                maxPrice,
                sampleSize: prices.length,
                properties,
            };
        }
        catch (error) {
            this.logger.error('Error parsing rental data from HTML', error);
            return null;
        }
    }
}
exports.RentalDataAnalyzer = RentalDataAnalyzer;


/***/ }),

/***/ 47:
/***/ (function(__unused_webpack_module, exports) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.IntersectionSimpleLazyLoader = void 0;
class IntersectionSimpleLazyLoader {
    logger;
    observer = null;
    processedElements = new Set();
    constructor(logger) {
        this.logger = logger;
    }
    observeElements(elements, callback) {
        if (!this.observer) {
            this.observer = new IntersectionObserver((entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting && !this.processedElements.has(entry.target)) {
                        this.processedElements.add(entry.target);
                        callback(entry.target);
                        this.observer.unobserve(entry.target);
                    }
                });
            }, {
                rootMargin: '100px',
                threshold: 0.1,
            });
        }
        elements.forEach((element) => {
            if (!this.processedElements.has(element)) {
                this.observer.observe(element);
            }
        });
    }
    disconnect() {
        if (this.observer) {
            this.observer.disconnect();
            this.processedElements.clear();
            this.observer = null;
        }
    }
}
exports.IntersectionSimpleLazyLoader = IntersectionSimpleLazyLoader;


/***/ }),

/***/ 75:
/***/ (function(__unused_webpack_module, exports) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.RobustErrorHandler = void 0;
class RobustErrorHandler {
    logger;
    maxRetries = 3;
    baseDelay = 1000;
    errorCounts = new Map();
    constructor(logger) {
        this.logger = logger;
    }
    handleError(error, context) {
        const errorKey = `${context.operation}-${error.name}`;
        const currentCount = this.errorCounts.get(errorKey) || 0;
        this.errorCounts.set(errorKey, currentCount + 1);
        this.logger.error(`Error in ${context.operation}`, {
            error: error.message,
            stack: error.stack,
            context,
            errorCount: currentCount + 1,
        });
        if (error.message.includes('fetch')) {
            this.logger.error('Network error detected', {
                url: context.url,
                propertyId: context.propertyId,
            });
        }
        else if (error.message.includes('parse') || error.message.includes('DOM')) {
            this.logger.error('Parsing error detected', {
                operation: context.operation,
                additionalData: context.additionalData,
            });
        }
    }
    shouldRetry(error, attemptCount) {
        if (attemptCount >= this.maxRetries) {
            return false;
        }
        if (error.message.includes('fetch') || error.message.includes('network') || error.message.includes('timeout')) {
            return true;
        }
        if (error.message.includes('500') ||
            error.message.includes('502') ||
            error.message.includes('503') ||
            error.message.includes('504')) {
            return true;
        }
        return false;
    }
    getRetryDelay(attemptCount) {
        const delay = this.baseDelay * Math.pow(2, attemptCount);
        const jitter = Math.random() * 0.1 * delay;
        return delay + jitter;
    }
    getErrorStats() {
        return Object.fromEntries(this.errorCounts);
    }
    clearErrorStats() {
        this.errorCounts.clear();
        this.logger.log('Error statistics cleared');
    }
}
exports.RobustErrorHandler = RobustErrorHandler;


/***/ }),

/***/ 169:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ProfitabilityCalculator = void 0;
const config_service_1 = __webpack_require__(294);
class ProfitabilityCalculator {
    logger;
    config;
    DEFAULT_CONFIG = {
        propertyManagementRate: 0.09,
        insuranceRate: 0.002,
        propertyTaxRate: 0.007,
        communityFeesWithGarage: 80,
        communityFeesWithoutGarage: 40,
        vacancyMaintenanceRate: 0.05,
    };
    configService;
    userConfig;
    constructor(logger, config = {}) {
        this.logger = logger;
        this.config = config;
        this.config = { ...this.DEFAULT_CONFIG, ...config };
        this.configService = new config_service_1.ConfigService();
    }
    async calculateProfitability(property, rentalData) {
        if (!this.userConfig) {
            this.userConfig = await this.configService.getConfig();
        }
        const activeConfig = this.userConfig.expenseConfig;
        const monthlyRent = rentalData.averagePrice;
        const annualRent = monthlyRent * 12;
        const purchasePrice = property.price;
        const grossYield = (annualRent / purchasePrice) * 100;
        const monthlyExpenses = this.calculateMonthlyExpenses(property, monthlyRent, activeConfig);
        const annualExpenses = monthlyExpenses * 12;
        const netAnnualRent = annualRent - annualExpenses;
        const netYield = Math.max(0, (netAnnualRent / purchasePrice) * 100);
        const { recommendation, riskLevel } = this.evaluateInvestment(grossYield, netYield, rentalData.sampleSize);
        this.logger.log(`Profitability calculation for ${property.id}: Gross ${grossYield.toFixed(2)}%, Net ${netYield.toFixed(2)}%`);
        return {
            propertyId: property.id,
            purchasePrice,
            estimatedRent: monthlyRent,
            grossYield: Math.round(grossYield * 100) / 100,
            netYield: Math.round(netYield * 100) / 100,
            monthlyExpenses,
            recommendation,
            riskLevel,
        };
    }
    calculateMonthlyExpenses(property, monthlyRent, expenseConfig) {
        let expenses = 0;
        expenses += expenseConfig.propertyManagementMonthly || 150;
        expenses += expenseConfig.insuranceMonthly || 50;
        expenses += expenseConfig.propertyTaxMonthly || 100;
        expenses += expenseConfig.communityFees || 60;
        expenses += monthlyRent * (expenseConfig.vacancyMaintenanceRate || 0.05);
        expenses += monthlyRent * (expenseConfig.maintenanceContingencyRate || 0.01);
        return Math.round(expenses);
    }
    evaluateInvestment(grossYield, netYield, sampleSize) {
        let recommendation;
        let riskLevel;
        const thresholds = this.userConfig?.profitabilityThresholds || {
            excellent: 6,
            good: 4,
            fair: 2,
        };
        if (netYield >= thresholds.excellent) {
            recommendation = 'excellent';
        }
        else if (netYield >= thresholds.good) {
            recommendation = 'good';
        }
        else if (netYield >= thresholds.fair) {
            recommendation = 'fair';
        }
        else {
            recommendation = 'poor';
        }
        if (sampleSize < 3) {
            riskLevel = 'high';
        }
        else if (grossYield > 8 || netYield < 1) {
            riskLevel = 'high';
        }
        else if (netYield >= 3 && grossYield <= 7) {
            riskLevel = 'low';
        }
        else {
            riskLevel = 'medium';
        }
        return { recommendation, riskLevel };
    }
}
exports.ProfitabilityCalculator = ProfitabilityCalculator;


/***/ }),

/***/ 273:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.IdealistaInvestmentAnalyzer = void 0;
const content_cache_service_1 = __webpack_require__(420);
const error_handler_1 = __webpack_require__(75);
const profitability_calculator_1 = __webpack_require__(169);
const property_extractor_1 = __webpack_require__(922);
const rental_data_analyzer_1 = __webpack_require__(16);
const simple_lazy_loader_1 = __webpack_require__(47);
const url_analyzer_1 = __webpack_require__(516);
const url_generator_1 = __webpack_require__(841);
const logger_1 = __webpack_require__(530);
const ui_renderer_1 = __webpack_require__(677);
class IdealistaInvestmentAnalyzer {
    languageService;
    logger;
    urlAnalyzer;
    propertyExtractor;
    rentalDataAnalyzer;
    profitabilityCalculator;
    urlGenerator;
    uiRenderer;
    cacheService;
    errorHandler;
    lazyLoader;
    constructor(languageService) {
        this.languageService = languageService;
        this.logger = new logger_1.Logger('IdealistaInvestmentAnalyzer');
        this.urlAnalyzer = new url_analyzer_1.UrlAnalyzer(this.logger);
        this.propertyExtractor = new property_extractor_1.PropertyExtractor(this.logger);
        this.cacheService = new content_cache_service_1.ContentCacheService(this.logger);
        this.errorHandler = new error_handler_1.RobustErrorHandler(this.logger);
        this.rentalDataAnalyzer = new rental_data_analyzer_1.RentalDataAnalyzer(this.logger, this.propertyExtractor, this.cacheService, this.errorHandler);
        this.profitabilityCalculator = new profitability_calculator_1.ProfitabilityCalculator(this.logger);
        this.urlGenerator = new url_generator_1.CrossReferenceUrlGenerator(this.logger);
        this.uiRenderer = new ui_renderer_1.InvestmentUIRenderer(this.logger, this.languageService);
        this.lazyLoader = new simple_lazy_loader_1.IntersectionSimpleLazyLoader(this.logger);
    }
    initialize() {
        this.logger.log('Initializing Idealista Investment Analyzer');
        if (this.urlAnalyzer.isIdealistaPropertyPage()) {
            this.logger.log('Idealista property page detected');
            this.analyzeCurrentPage();
        }
        else {
            this.logger.log('Not an Idealista property page');
        }
    }
    analyzeCurrentPage() {
        const urlAnalysis = this.urlAnalyzer.analyzeCurrentPage();
        if (urlAnalysis.searchType) {
            this.startPropertyAnalysis(urlAnalysis);
        }
    }
    startPropertyAnalysis(urlAnalysis) {
        this.logger.log(`Starting analysis for ${urlAnalysis.searchType} properties in ${urlAnalysis.location}`);
        const properties = this.propertyExtractor.extractPropertiesFromPage();
        this.logger.log(`Found ${properties.length} properties on page`);
        if (properties.length > 0) {
            this.processProperties(properties, urlAnalysis);
        }
    }
    processProperties(properties, urlAnalysis) {
        this.logger.log('Processing properties for investment analysis');
        if (urlAnalysis.searchType !== 'venta') {
            this.logger.log('Skipping analysis - not a sale search');
            return;
        }
        const propertyElements = properties
            .map((property) => {
            const element = document.querySelector(`article.item[data-element-id="${property.id}"]`);
            return { property, element };
        })
            .filter((item) => item.element !== null);
        if (propertyElements.length === 0) {
            this.logger.log('No property elements found, processing directly with delays');
            this.processBatch(properties, urlAnalysis);
            return;
        }
        const elements = propertyElements.map((item) => item.element);
        this.lazyLoader.observeElements(elements, (element) => {
            const propertyData = propertyElements.find((item) => item.element === element)?.property;
            if (propertyData) {
                this.analyzePropertyProfitability(propertyData, urlAnalysis);
            }
        });
    }
    async processBatch(properties, urlAnalysis) {
        this.logger.log('Processing properties in batch mode with delays');
        for (const property of properties) {
            await this.analyzePropertyProfitability(property, urlAnalysis);
            await this.delay(2000);
        }
    }
    delay(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
    async analyzePropertyProfitability(property, urlAnalysis) {
        this.logger.log(`Analyzing property ${property.id}: ${property.price}€ - ${property.rooms} hab., ${property.size}m²`);
        const context = {
            operation: 'analyzePropertyProfitability',
            propertyId: property.id,
            additionalData: { price: property.price, rooms: property.rooms, size: property.size },
        };
        try {
            await this.uiRenderer.renderLoadingBadge(property);
            const rentalUrl = this.urlGenerator.generateRentalUrl(urlAnalysis.location, property);
            this.logger.log(`Fetching rental data from: ${rentalUrl}`);
            const rentalData = await this.rentalDataAnalyzer.fetchRentalData(rentalUrl);
            if (rentalData && rentalData.sampleSize > 0) {
                const analysis = await this.profitabilityCalculator.calculateProfitability(property, rentalData);
                this.logger.log(`Profitability analysis for ${property.id}:`, analysis);
                await this.uiRenderer.renderBadge(property, analysis);
            }
            else {
                this.logger.log(`No rental data found for property ${property.id}`);
                this.handleMissingData(property);
            }
        }
        catch (error) {
            this.errorHandler.handleError(error, context);
            this.handleAnalysisError(property);
        }
    }
    handleMissingData(property) {
        this.uiRenderer.renderNoDataBadge(property);
    }
    handleAnalysisError(property) {
        this.uiRenderer.renderErrorBadge(property);
    }
}
exports.IdealistaInvestmentAnalyzer = IdealistaInvestmentAnalyzer;


/***/ }),

/***/ 294:
/***/ (function(__unused_webpack_module, exports) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ConfigService = void 0;
class ConfigService {
    static STORAGE_KEY = 'investmentAnalysisConfig';
    static DEFAULT_CONFIG = {
        expenseConfig: {
            propertyManagementMonthly: 150,
            insuranceMonthly: 50,
            propertyTaxMonthly: 100,
            communityFees: 60,
            vacancyMaintenanceRate: 0.05,
            maintenanceContingencyRate: 0.01,
        },
        mortgageConfig: {
            loanToValueRatio: 0.8,
            managementFeesRate: 0.1,
            interestRate: 2.45,
        },
        profitabilityThresholds: {
            excellent: 6,
            good: 4,
            fair: 2,
        },
        displayOptions: {
            showBadges: true,
            showModal: true,
            showLoadingStates: true,
        },
    };
    async getConfig() {
        try {
            const result = await chrome.storage.sync.get(ConfigService.STORAGE_KEY);
            const storedConfig = result[ConfigService.STORAGE_KEY];
            if (!storedConfig) {
                return ConfigService.DEFAULT_CONFIG;
            }
            const migratedConfig = this.migrateOldConfig(storedConfig);
            return { ...ConfigService.DEFAULT_CONFIG, ...migratedConfig };
        }
        catch (error) {
            console.error('Error loading config:', error);
            return ConfigService.DEFAULT_CONFIG;
        }
    }
    migrateOldConfig(config) {
        if (config.expenseConfig) {
            if (config.expenseConfig.communityFeesWithGarage && !config.expenseConfig.communityFees) {
                const avgCommunity = Math.round(((config.expenseConfig.communityFeesWithGarage || 80) +
                    (config.expenseConfig.communityFeesWithoutGarage || 40)) /
                    2);
                config.expenseConfig.communityFees = avgCommunity;
                delete config.expenseConfig.communityFeesWithGarage;
                delete config.expenseConfig.communityFeesWithoutGarage;
            }
        }
        return config;
    }
    async updateConfig(partialConfig) {
        try {
            const currentConfig = await this.getConfig();
            const newConfig = { ...currentConfig, ...partialConfig };
            await chrome.storage.sync.set({
                [ConfigService.STORAGE_KEY]: newConfig,
            });
        }
        catch (error) {
            console.error('Error saving config:', error);
            throw error;
        }
    }
    async resetToDefaults() {
        try {
            await chrome.storage.sync.set({
                [ConfigService.STORAGE_KEY]: ConfigService.DEFAULT_CONFIG,
            });
        }
        catch (error) {
            console.error('Error resetting config:', error);
            throw error;
        }
    }
}
exports.ConfigService = ConfigService;


/***/ }),

/***/ 420:
/***/ (function(__unused_webpack_module, exports) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ContentCacheService = void 0;
class ContentCacheService {
    logger;
    constructor(logger) {
        this.logger = logger;
    }
    async get(key) {
        try {
            const response = await chrome.runtime.sendMessage({
                type: 'CACHE_GET',
                key,
            });
            if (!response.success) {
                throw new Error(response.error);
            }
            return response.data;
        }
        catch (error) {
            this.logger.error(`Error getting cache for key ${key}:`, error);
            return null;
        }
    }
    async set(key, data, ttl) {
        try {
            const response = await chrome.runtime.sendMessage({
                type: 'CACHE_SET',
                key,
                data,
                ttl,
            });
            if (!response.success) {
                throw new Error(response.error);
            }
        }
        catch (error) {
            this.logger.error(`Error setting cache for key ${key}:`, error);
        }
    }
    async clear() {
        try {
            const response = await chrome.runtime.sendMessage({
                type: 'CACHE_CLEAR',
            });
            if (!response.success) {
                throw new Error(response.error);
            }
        }
        catch (error) {
            this.logger.error('Error clearing cache:', error);
        }
    }
    async cleanup() {
        try {
            const response = await chrome.runtime.sendMessage({
                type: 'CACHE_CLEANUP',
            });
            if (!response.success) {
                throw new Error(response.error);
            }
        }
        catch (error) {
            this.logger.error('Error during cache cleanup:', error);
        }
    }
}
exports.ContentCacheService = ContentCacheService;


/***/ }),

/***/ 516:
/***/ (function(__unused_webpack_module, exports) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UrlAnalyzer = void 0;
class UrlAnalyzer {
    logger;
    constructor(logger) {
        this.logger = logger;
    }
    analyzeCurrentPage() {
        const url = new URL(window.location.href);
        return this.analyzeUrl(url);
    }
    analyzeUrl(url) {
        const pathname = url.pathname;
        const searchParams = url.searchParams;
        let searchType = null;
        if (pathname.includes('/venta-viviendas/')) {
            searchType = 'venta';
        }
        else if (pathname.includes('/alquiler-viviendas/')) {
            searchType = 'alquiler';
        }
        const location = this.extractLocationFromUrl(pathname);
        const hasFilters = searchParams.toString().length > 0;
        const isIdealista = url.hostname === 'www.idealista.com' &&
            (pathname.includes('/venta-viviendas/') || pathname.includes('/alquiler-viviendas/'));
        const result = {
            isIdealista,
            searchType,
            location,
            hasFilters,
        };
        this.logger.log('URL Analysis:', result);
        return result;
    }
    isIdealistaPropertyPage() {
        const hostname = window.location.hostname;
        const pathname = window.location.pathname;
        return (hostname === 'www.idealista.com' &&
            (pathname.includes('/venta-viviendas/') || pathname.includes('/alquiler-viviendas/')));
    }
    extractLocationFromUrl(pathname) {
        const match = pathname.match(/\/(venta|alquiler)-viviendas\/([^/]+)/);
        return match ? match[2] : null;
    }
}
exports.UrlAnalyzer = UrlAnalyzer;


/***/ }),

/***/ 530:
/***/ (function(__unused_webpack_module, exports) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Logger = void 0;
class Logger {
    context;
    constructor(context) {
        this.context = context;
    }
    log(message, data) {
        const timestamp = new Date().toISOString();
        const prefix = `[${timestamp}][${this.context}]`;
        if (data) {
            console.log(`${prefix} ${message}`, data);
        }
        else {
            console.log(`${prefix} ${message}`);
        }
    }
    error(message, error) {
        const timestamp = new Date().toISOString();
        const prefix = `[${timestamp}][${this.context}][ERROR]`;
        if (error) {
            console.error(`${prefix} ${message}`, error);
        }
        else {
            console.error(`${prefix} ${message}`);
        }
    }
}
exports.Logger = Logger;


/***/ }),

/***/ 677:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.InvestmentUIRenderer = void 0;
const config_service_1 = __webpack_require__(294);
class InvestmentUIRenderer {
    logger;
    languageService;
    configService;
    userConfig;
    constructor(logger, languageService) {
        this.logger = logger;
        this.languageService = languageService;
        this.configService = new config_service_1.ConfigService();
    }
    async renderBadge(property, analysis) {
        if (!this.userConfig) {
            this.userConfig = await this.configService.getConfig();
        }
        if (!this.userConfig.displayOptions.showBadges) {
            return;
        }
        const propertyElement = this.findPropertyElement(property.id);
        if (!propertyElement) {
            this.logger.error(`Property element not found for ID: ${property.id}`);
            return;
        }
        this.removeBadge(property);
        const analysisButton = this.createAnalysisButton(property, analysis);
        const descriptionContainer = propertyElement.querySelector('.item-description');
        if (descriptionContainer) {
            descriptionContainer.parentNode?.insertBefore(analysisButton, descriptionContainer.nextSibling);
            this.logger.log(`Investment analysis button rendered for property ${property.id}: ${analysis.recommendation}`);
        }
        else {
            this.logger.error(`Description container not found for property ${property.id}`);
        }
    }
    async renderLoadingBadge(property) {
        if (!this.userConfig) {
            this.userConfig = await this.configService.getConfig();
        }
        if (!this.userConfig.displayOptions.showLoadingStates) {
            return;
        }
        const propertyElement = this.findPropertyElement(property.id);
        if (!propertyElement)
            return;
        this.removeBadge(property);
        const badge = document.createElement('div');
        badge.className = 'investment-badge investment-badge--loading';
        badge.setAttribute('data-property-id', property.id);
        badge.textContent = this.languageService.getMessage('analyzing');
        const multimediaContainer = propertyElement.querySelector('.item-multimedia');
        if (multimediaContainer) {
            multimediaContainer.appendChild(badge);
            this.logger.log(`Loading badge rendered for property ${property.id}`);
        }
    }
    renderNoDataBadge(property) {
        const propertyElement = this.findPropertyElement(property.id);
        if (!propertyElement)
            return;
        this.removeBadge(property);
        const badge = document.createElement('div');
        badge.className = 'investment-badge investment-badge--no-data';
        badge.setAttribute('data-property-id', property.id);
        badge.innerHTML = `
      <div class="investment-badge__content">
        <div class="investment-badge__icon">📊</div>
        <div class="investment-badge__text">${this.languageService.getMessage('noRentalData')}</div>
      </div>
    `;
        const multimediaContainer = propertyElement.querySelector('.item-multimedia');
        if (multimediaContainer) {
            multimediaContainer.appendChild(badge);
            this.logger.log(`No data badge rendered for property ${property.id}`);
        }
    }
    renderErrorBadge(property) {
        const propertyElement = this.findPropertyElement(property.id);
        if (!propertyElement)
            return;
        this.removeBadge(property);
        const badge = document.createElement('div');
        badge.className = 'investment-badge investment-badge--error';
        badge.setAttribute('data-property-id', property.id);
        badge.innerHTML = `
      <div class="investment-badge__content">
        <div class="investment-badge__icon">⚠️</div>
        <div class="investment-badge__text">${this.languageService.getMessage('analysisError')}</div>
      </div>
    `;
        const multimediaContainer = propertyElement.querySelector('.item-multimedia');
        if (multimediaContainer) {
            multimediaContainer.appendChild(badge);
            this.logger.log(`Error badge rendered for property ${property.id}`);
        }
    }
    removeBadge(property) {
        const existingElements = document.querySelectorAll(`[data-property-id="${property.id}"]`);
        existingElements.forEach((element) => element.remove());
    }
    findPropertyElement(propertyId) {
        return document.querySelector(`article.item[data-element-id="${propertyId}"]`);
    }
    createAnalysisButton(property, analysis) {
        const buttonContainer = document.createElement('div');
        buttonContainer.className = 'investment-analysis-container';
        buttonContainer.setAttribute('data-property-id', analysis.propertyId);
        const button = document.createElement('button');
        button.className = `investment-analysis-button investment-analysis-button--${analysis.recommendation}`;
        button.innerHTML = `
      <div class="investment-analysis-button__content">
        <div class="investment-analysis-button__yield">
          <span class="investment-analysis-button__yield-label">${this.languageService.getMessage('netProfitability')}</span>
          <span class="investment-analysis-button__yield-value">${analysis.netYield}%</span>
        </div>
        <div class="investment-analysis-button__recommendation">
          ${this.getRecommendationText(analysis.recommendation)}
        </div>
        <div class="investment-analysis-button__icon">📊</div>
      </div>
    `;
        button.addEventListener('click', async (e) => {
            e.preventDefault();
            e.stopPropagation();
            if (!this.userConfig) {
                this.userConfig = await this.configService.getConfig();
            }
            if (this.userConfig.displayOptions.showModal) {
                this.openAnalysisModal(property, analysis);
                this.logger.log(`Investment modal opened for property ${property.id}`);
            }
        });
        buttonContainer.appendChild(button);
        return buttonContainer;
    }
    openAnalysisModal(property, analysis) {
        const modalRenderer = new ModalRenderer(this.logger, this.languageService);
        modalRenderer.openModal(property, analysis);
    }
    getRecommendationText(recommendation) {
        switch (recommendation) {
            case 'excellent':
                return this.languageService.getMessage('excellentInvestment');
            case 'good':
                return this.languageService.getMessage('goodInvestment');
            case 'fair':
                return this.languageService.getMessage('regularInvestment');
            case 'poor':
                return this.languageService.getMessage('badInvestment');
            default:
                return this.languageService.getMessage('unknownInvestment');
        }
    }
}
exports.InvestmentUIRenderer = InvestmentUIRenderer;
class ModalRenderer {
    logger;
    languageService;
    constructor(logger, languageService) {
        this.logger = logger;
        this.languageService = languageService;
    }
    openModal(property, analysis) {
        const existingModal = document.querySelector('.investment-modal-overlay');
        if (existingModal) {
            existingModal.remove();
        }
        const modalOverlay = document.createElement('div');
        modalOverlay.className = 'investment-modal-overlay';
        const modal = document.createElement('div');
        modal.className = 'investment-modal';
        modal.innerHTML = this.createModalContent(property, analysis);
        modalOverlay.appendChild(modal);
        document.body.appendChild(modalOverlay);
        this.addEventListeners(modal, modalOverlay);
    }
    createModalContent(property, analysis) {
        return `
      <div class="investment-modal__header">
        <h3 class="investment-modal__title">${this.languageService.getMessage('investmentAnalysisTitle')}</h3>
        <button class="investment-modal__close">×</button>
      </div>
      
      <div class="investment-modal__content">
        <div class="investment-modal__property-info">
          <h4>${property.title}</h4>
          <p class="investment-modal__property-details">
            ${property.rooms ? property.rooms + this.languageService.getMessage('roomsSuffix') : ''} 
            ${property.size ? property.size + this.languageService.getMessage('sizeSuffix') : ''}
            ${property.floor ? ' • ' + property.floor : ''}
          </p>
        </div>

        <div class="investment-modal__analysis">
          <div class="investment-modal__recommendation investment-modal__recommendation--${analysis.recommendation}">
            <div class="investment-modal__recommendation-text">
              ${this.getRecommendationText(analysis.recommendation)}
            </div>
            <div class="investment-modal__recommendation-yield">
              ${this.languageService.getMessage('netProfitability')} ${analysis.netYield}%
            </div>
          </div>

          <div class="investment-modal__details-grid">
            <div class="investment-modal__detail-item">
              <span class="investment-modal__label">${this.languageService.getMessage('purchasePrice')}</span>
              <span class="investment-modal__value">${this.languageService.formatCurrency(analysis.purchasePrice)}</span>
            </div>
            
            <div class="investment-modal__detail-item">
              <span class="investment-modal__label">${this.languageService.getMessage('monthlyRentalEstimate')}</span>
              <span class="investment-modal__value">${this.languageService.formatCurrency(analysis.estimatedRent)}</span>
            </div>
            
            <div class="investment-modal__detail-item">
              <span class="investment-modal__label">${this.languageService.getMessage('monthlyExpensesEstimate')}</span>
              <span class="investment-modal__value">${this.languageService.formatCurrency(analysis.monthlyExpenses)}</span>
            </div>
            
            <div class="investment-modal__divider"></div>
            
            <div class="investment-modal__detail-item">
              <span class="investment-modal__label">${this.languageService.getMessage('grossAnnualProfitability')}</span>
              <span class="investment-modal__value">${analysis.grossYield}%</span>
            </div>
            
            <div class="investment-modal__detail-item investment-modal__detail-item--highlight">
              <span class="investment-modal__label">${this.languageService.getMessage('netAnnualProfitability')}</span>
              <span class="investment-modal__value">${analysis.netYield}%</span>
            </div>
            
            <div class="investment-modal__risk investment-modal__risk--${analysis.riskLevel}">
              <div class="investment-modal__risk-dot"></div>
              <span>${this.languageService.getMessage('riskLevel')}${analysis.riskLevel.toUpperCase()}</span>
            </div>
          </div>
        </div>
      </div>
    `;
    }
    addEventListeners(modal, modalOverlay) {
        const closeButton = modal.querySelector('.investment-modal__close');
        closeButton?.addEventListener('click', () => {
            modalOverlay.remove();
        });
        modalOverlay.addEventListener('click', (e) => {
            if (e.target === modalOverlay) {
                modalOverlay.remove();
            }
        });
        const handleEscape = (e) => {
            if (e.key === 'Escape') {
                modalOverlay.remove();
                document.removeEventListener('keydown', handleEscape);
            }
        };
        document.addEventListener('keydown', handleEscape);
    }
    getRecommendationText(recommendation) {
        switch (recommendation) {
            case 'excellent':
                return this.languageService.getMessage('excellentInvestment');
            case 'good':
                return this.languageService.getMessage('goodInvestment');
            case 'fair':
                return this.languageService.getMessage('regularInvestment');
            case 'poor':
                return this.languageService.getMessage('badInvestment');
            default:
                return this.languageService.getMessage('unknownInvestment');
        }
    }
}


/***/ }),

/***/ 714:
/***/ (function(__unused_webpack_module, exports) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.LanguageService = void 0;
class LanguageService {
    static SUPPORTED_LANGUAGES = ['es', 'en', 'fr'];
    static DEFAULT_LANGUAGE = 'en';
    static LOCALE_MAP = {
        'es': 'es-ES',
        'en': 'en-US',
        'fr': 'fr-FR'
    };
    currentLanguage = LanguageService.DEFAULT_LANGUAGE;
    messages = {};
    initialized = false;
    constructor() {
        this.loadMessages();
    }
    async initialize() {
        if (this.initialized)
            return;
        try {
            const result = await chrome.storage.local.get(['language']);
            if (result.language && this.isValidLanguage(result.language)) {
                this.currentLanguage = result.language;
            }
            else {
                const browserLang = this.getBrowserLanguage();
                this.currentLanguage = this.isValidLanguage(browserLang) ? browserLang : LanguageService.DEFAULT_LANGUAGE;
                await chrome.storage.local.set({ language: this.currentLanguage });
            }
        }
        catch (error) {
            console.warn('Error initializing language:', error);
            this.currentLanguage = LanguageService.DEFAULT_LANGUAGE;
        }
        this.initialized = true;
    }
    isValidLanguage(language) {
        return LanguageService.SUPPORTED_LANGUAGES.includes(language);
    }
    static getSupportedLanguages() {
        return [...LanguageService.SUPPORTED_LANGUAGES];
    }
    getBrowserLanguage() {
        if (typeof chrome !== 'undefined' && chrome.i18n && chrome.i18n.getUILanguage) {
            return chrome.i18n.getUILanguage().split('-')[0];
        }
        return navigator.language?.split('-')[0] || 'en';
    }
    loadMessages() {
        this.messages['es'] = {
            appName: 'Análisis de Inversión Inmobiliaria',
            popupTitle: 'Configuración - Análisis de Inversión',
            configurationTitle: 'Configuración de Análisis',
            languageSelector: 'Idioma',
            languageSpanish: 'Español',
            languageEnglish: 'Inglés',
            languageFrench: 'Francés',
            estimatedExpensesTitle: 'Gastos Estimados',
            propertyManagementLabel: 'Gestión inmobiliaria (€)',
            monthlyFixedCost: 'Coste mensual fijo',
            insuranceLabel: 'Seguro (€)',
            ibiLabel: 'IBI (€)',
            vacancyLabel: 'Vacancia (%)',
            rentalPercentage: '% del alquiler',
            repairsLabel: 'Reparaciones y contingencias (%)',
            repairsHelp: '% del alquiler para calentadores, averías, mejoras, etc.',
            communityLabel: 'Comunidad (€)',
            communityHelp: 'Gastos de comunidad mensual',
            mortgageConfigTitle: 'Configuración de Hipoteca',
            financingLabel: 'Financiación (%)',
            priceFinnancedPercentage: '% del precio financiado',
            interestLabel: 'Interés (%)',
            annualTinHelp: 'TIN anual de la hipoteca',
            managementFeesLabel: 'Gastos de gestión (%)',
            managementFeesHelp: '% del precio de compra (notaría, registro, tasación, etc.)',
            profitabilityThresholdsTitle: 'Umbrales de Rentabilidad',
            excellentLabel: 'Excelente (%)',
            goodLabel: 'Buena (%)',
            regularLabel: 'Regular (%)',
            displayOptionsTitle: 'Opciones de Visualización',
            showProfitabilityIndicators: 'Mostrar indicadores de rentabilidad',
            allowDetailsModal: 'Permitir modal de detalles',
            showLoadingStates: 'Mostrar estados de carga',
            restoreButton: 'Restaurar',
            saveButton: 'Guardar',
            errorLoadingConfig: 'Error al cargar la configuración',
            configSavedSuccessfully: 'Configuración guardada correctamente',
            errorSavingConfig: 'Error al guardar la configuración',
            configRestoredSuccessfully: 'Configuración restaurada a valores por defecto',
            errorRestoringConfig: 'Error al restaurar la configuración',
            analyzing: 'Analizando...',
            noRentalData: 'Sin datos de alquiler',
            analysisError: 'Error en análisis',
            netProfitability: 'Rentabilidad Neta:',
            excellentInvestment: 'EXCELENTE INVERSIÓN',
            goodInvestment: 'BUENA INVERSIÓN',
            regularInvestment: 'INVERSIÓN REGULAR',
            badInvestment: 'MALA INVERSIÓN',
            unknownInvestment: 'DESCONOCIDO',
            investmentAnalysisTitle: 'Análisis de Inversión',
            roomsSuffix: ' hab.',
            sizeSuffix: 'm²',
            purchasePrice: 'Precio de compra',
            monthlyRentalEstimate: 'Alquiler estimado mensual',
            monthlyExpensesEstimate: 'Gastos mensuales estimados',
            grossAnnualProfitability: 'Rentabilidad bruta anual',
            netAnnualProfitability: 'Rentabilidad neta anual',
            riskLevel: 'Nivel de riesgo: '
        };
        this.messages['en'] = {
            appName: 'Real Estate Investment Analysis',
            popupTitle: 'Configuration - Investment Analysis',
            configurationTitle: 'Analysis Configuration',
            languageSelector: 'Language',
            languageSpanish: 'Spanish',
            languageEnglish: 'English',
            languageFrench: 'French',
            estimatedExpensesTitle: 'Estimated Expenses',
            propertyManagementLabel: 'Property management (€)',
            monthlyFixedCost: 'Monthly fixed cost',
            insuranceLabel: 'Insurance (€)',
            ibiLabel: 'Property tax (€)',
            vacancyLabel: 'Vacancy (%)',
            rentalPercentage: '% of rental income',
            repairsLabel: 'Repairs and contingencies (%)',
            repairsHelp: '% of rental for heating, breakdowns, improvements, etc.',
            communityLabel: 'Community fees (€)',
            communityHelp: 'Monthly community expenses',
            mortgageConfigTitle: 'Mortgage Configuration',
            financingLabel: 'Financing (%)',
            priceFinnancedPercentage: '% of price financed',
            interestLabel: 'Interest (%)',
            annualTinHelp: 'Annual mortgage interest rate',
            managementFeesLabel: 'Management fees (%)',
            managementFeesHelp: '% of purchase price (notary, registry, appraisal, etc.)',
            profitabilityThresholdsTitle: 'Profitability Thresholds',
            excellentLabel: 'Excellent (%)',
            goodLabel: 'Good (%)',
            regularLabel: 'Regular (%)',
            displayOptionsTitle: 'Display Options',
            showProfitabilityIndicators: 'Show profitability indicators',
            allowDetailsModal: 'Allow details modal',
            showLoadingStates: 'Show loading states',
            restoreButton: 'Restore',
            saveButton: 'Save',
            errorLoadingConfig: 'Error loading configuration',
            configSavedSuccessfully: 'Configuration saved successfully',
            errorSavingConfig: 'Error saving configuration',
            configRestoredSuccessfully: 'Configuration restored to default values',
            errorRestoringConfig: 'Error restoring configuration',
            analyzing: 'Analyzing...',
            noRentalData: 'No rental data',
            analysisError: 'Analysis error',
            netProfitability: 'Net Profitability:',
            excellentInvestment: 'EXCELLENT INVESTMENT',
            goodInvestment: 'GOOD INVESTMENT',
            regularInvestment: 'REGULAR INVESTMENT',
            badInvestment: 'BAD INVESTMENT',
            unknownInvestment: 'UNKNOWN',
            investmentAnalysisTitle: 'Investment Analysis',
            roomsSuffix: ' rooms',
            sizeSuffix: 'm²',
            purchasePrice: 'Purchase price',
            monthlyRentalEstimate: 'Monthly rental estimate',
            monthlyExpensesEstimate: 'Monthly expenses estimate',
            grossAnnualProfitability: 'Gross annual profitability',
            netAnnualProfitability: 'Net annual profitability',
            riskLevel: 'Risk level: '
        };
        this.messages['fr'] = {
            appName: 'Analyse d\'Investissement Immobilier',
            popupTitle: 'Configuration - Analyse d\'Investissement',
            configurationTitle: 'Configuration de l\'Analyse',
            languageSelector: 'Langue',
            languageSpanish: 'Espagnol',
            languageEnglish: 'Anglais',
            languageFrench: 'Français',
            estimatedExpensesTitle: 'Dépenses Estimées',
            propertyManagementLabel: 'Gestion immobilière (€)',
            monthlyFixedCost: 'Coût mensuel fixe',
            insuranceLabel: 'Assurance (€)',
            ibiLabel: 'Taxe foncière (€)',
            vacancyLabel: 'Vacance (%)',
            rentalPercentage: '% du revenu locatif',
            repairsLabel: 'Réparations et contingences (%)',
            repairsHelp: '% du loyer pour chauffage, pannes, améliorations, etc.',
            communityLabel: 'Charges de copropriété (€)',
            communityHelp: 'Charges mensuelles de copropriété',
            mortgageConfigTitle: 'Configuration Hypothécaire',
            financingLabel: 'Financement (%)',
            priceFinnancedPercentage: '% du prix financé',
            interestLabel: 'Intérêt (%)',
            annualTinHelp: 'Taux d\'intérêt annuel de l\'hypothèque',
            managementFeesLabel: 'Frais de gestion (%)',
            managementFeesHelp: '% du prix d\'achat (notaire, registre, évaluation, etc.)',
            profitabilityThresholdsTitle: 'Seuils de Rentabilité',
            excellentLabel: 'Excellent (%)',
            goodLabel: 'Bon (%)',
            regularLabel: 'Régulier (%)',
            displayOptionsTitle: 'Options d\'Affichage',
            showProfitabilityIndicators: 'Afficher les indicateurs de rentabilité',
            allowDetailsModal: 'Permettre le modal de détails',
            showLoadingStates: 'Afficher les états de chargement',
            restoreButton: 'Restaurer',
            saveButton: 'Sauvegarder',
            errorLoadingConfig: 'Erreur lors du chargement de la configuration',
            configSavedSuccessfully: 'Configuration sauvegardée avec succès',
            errorSavingConfig: 'Erreur lors de la sauvegarde de la configuration',
            configRestoredSuccessfully: 'Configuration restaurée aux valeurs par défaut',
            errorRestoringConfig: 'Erreur lors de la restauration de la configuration',
            analyzing: 'Analyse en cours...',
            noRentalData: 'Aucune donnée locative',
            analysisError: 'Erreur d\'analyse',
            netProfitability: 'Rentabilité Nette:',
            excellentInvestment: 'EXCELLENT INVESTISSEMENT',
            goodInvestment: 'BON INVESTISSEMENT',
            regularInvestment: 'INVESTISSEMENT RÉGULIER',
            badInvestment: 'MAUVAIS INVESTISSEMENT',
            unknownInvestment: 'INCONNU',
            investmentAnalysisTitle: 'Analyse d\'Investissement',
            roomsSuffix: ' pièces',
            sizeSuffix: 'm²',
            purchasePrice: 'Prix d\'achat',
            monthlyRentalEstimate: 'Estimation du loyer mensuel',
            monthlyExpensesEstimate: 'Estimation des dépenses mensuelles',
            grossAnnualProfitability: 'Rentabilité annuelle brute',
            netAnnualProfitability: 'Rentabilité annuelle nette',
            riskLevel: 'Niveau de risque: '
        };
    }
    async setLanguage(language) {
        if (this.isValidLanguage(language)) {
            this.currentLanguage = language;
            try {
                await chrome.storage.local.set({ language: language });
                this.notifyLanguageChange(language);
            }
            catch (error) {
                console.warn('Error saving language preference:', error);
            }
        }
    }
    notifyLanguageChange(language) {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const tab = tabs[0];
            if (tab?.id && tab.url) {
                console.log('Current tab URL:', tab.url);
                if (tab.url.includes('idealista.com')) {
                    console.log('Sending language change message to Idealista tab. Language:', language);
                    chrome.tabs.sendMessage(tab.id, {
                        type: 'LANGUAGE_CHANGED',
                        language: language
                    }).then(() => {
                        console.log('Language change message sent successfully');
                    }).catch((error) => {
                        console.warn('Error sending language change message:', error);
                    });
                }
                else {
                    console.log('Not an Idealista tab, skipping message send');
                }
            }
            else {
                console.warn('No active tab found or tab has no URL');
            }
        });
    }
    getLanguage() {
        return this.currentLanguage;
    }
    async loadLanguageFromStorage() {
        try {
            const result = await chrome.storage.local.get(['language']);
            if (result.language && this.isValidLanguage(result.language)) {
                this.currentLanguage = result.language;
            }
        }
        catch (error) {
            console.warn('Error loading language from storage:', error);
        }
    }
    getMessage(key) {
        return this.messages[this.currentLanguage]?.[key] || key;
    }
    formatCurrency(amount, currency = 'EUR') {
        try {
            const locale = LanguageService.LOCALE_MAP[this.currentLanguage] || LanguageService.LOCALE_MAP[LanguageService.DEFAULT_LANGUAGE];
            return new Intl.NumberFormat(locale, {
                style: 'currency',
                currency: currency,
                minimumFractionDigits: 0,
                maximumFractionDigits: 0
            }).format(amount);
        }
        catch (error) {
            console.warn('Error formatting currency:', error);
            return `${amount.toLocaleString()}€`;
        }
    }
    formatPercentage(value, decimals = 2) {
        try {
            const locale = LanguageService.LOCALE_MAP[this.currentLanguage] || LanguageService.LOCALE_MAP[LanguageService.DEFAULT_LANGUAGE];
            return new Intl.NumberFormat(locale, {
                style: 'percent',
                minimumFractionDigits: decimals,
                maximumFractionDigits: decimals
            }).format(value / 100);
        }
        catch (error) {
            console.warn('Error formatting percentage:', error);
            return `${value.toFixed(decimals)}%`;
        }
    }
}
exports.LanguageService = LanguageService;


/***/ }),

/***/ 841:
/***/ (function(__unused_webpack_module, exports) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CrossReferenceUrlGenerator = void 0;
class CrossReferenceUrlGenerator {
    logger;
    constructor(logger) {
        this.logger = logger;
    }
    generateRentalUrl(location, property) {
        const baseUrl = 'https://www.idealista.com/alquiler-viviendas';
        return this.buildUrl(baseUrl, location, property);
    }
    generateSaleUrl(location, property) {
        const baseUrl = 'https://www.idealista.com/venta-viviendas';
        return this.buildUrl(baseUrl, location, property);
    }
    buildUrl(baseUrl, location, property) {
        if (!location) {
            this.logger.error('No location provided for URL generation');
            return `${baseUrl}/`;
        }
        let url = `${baseUrl}/${location}/`;
        const params = new URLSearchParams();
        if (property.rooms && property.rooms > 0) {
            params.append('habitaciones', property.rooms.toString());
        }
        if (property.size && property.size > 0) {
            const minSize = Math.max(1, property.size - 20);
            const maxSize = property.size + 20;
            params.append('superficie', `${minSize}-${maxSize}`);
        }
        const paramString = params.toString();
        if (paramString) {
            url += `?${paramString}`;
        }
        return url;
    }
}
exports.CrossReferenceUrlGenerator = CrossReferenceUrlGenerator;


/***/ }),

/***/ 922:
/***/ (function(__unused_webpack_module, exports) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.PropertyExtractor = void 0;
class PropertyExtractor {
    logger;
    constructor(logger) {
        this.logger = logger;
    }
    extractPropertiesFromPage() {
        const properties = [];
        const propertyElements = document.querySelectorAll('article.item[data-element-id]');
        this.logger.log(`Found ${propertyElements.length} property elements on page`);
        propertyElements.forEach((element) => {
            try {
                const property = this.extractPropertyData(element);
                if (property) {
                    properties.push(property);
                }
            }
            catch (error) {
                this.logger.error('Error extracting property data', error);
            }
        });
        return properties;
    }
    extractPropertiesFromDocument(doc) {
        const properties = [];
        const propertyElements = doc.querySelectorAll('article.item[data-element-id]');
        propertyElements.forEach((element) => {
            try {
                const property = this.extractPropertyDataFromElement(element);
                if (property) {
                    properties.push(property);
                }
            }
            catch (error) {
                this.logger.error('Error extracting property data from element', error);
            }
        });
        return properties;
    }
    extractPropertyData(element) {
        return this.extractPropertyDataFromElement(element);
    }
    extractPropertyDataFromElement(element) {
        const id = element.getAttribute('data-element-id');
        if (!id)
            return null;
        const priceElement = element.querySelector('.item-price');
        const priceText = priceElement?.textContent?.replace(/[€\s]/g, '').replace('.', '') || '0';
        const price = Number.parseInt(priceText, 10) || 0;
        const linkElement = element.querySelector('.item-link');
        const title = linkElement?.textContent?.trim() || '';
        const url = linkElement?.href || '';
        const details = element.querySelectorAll('.item-detail');
        let rooms = null;
        let size = null;
        let floor = null;
        details.forEach((detail) => {
            const text = detail.textContent?.trim() || '';
            if (text.includes('hab.')) {
                const roomMatch = text.match(/(\d+)\s*hab\./);
                rooms = roomMatch ? Number.parseInt(roomMatch[1], 10) : null;
            }
            else if (text.includes('m²')) {
                const sizeMatch = text.match(/(\d+)\s*m²/);
                size = sizeMatch ? Number.parseInt(sizeMatch[1], 10) : null;
            }
            else if (text.includes('Planta') || text.includes('Bajo')) {
                floor = text;
            }
        });
        const hasGarage = !!element.querySelector('.item-parking');
        const descriptionElement = element.querySelector('.item-description .ellipsis');
        const description = descriptionElement?.textContent?.trim() || '';
        const tagElements = element.querySelectorAll('.listing-tags');
        const tags = Array.from(tagElements).map((tag) => tag.textContent?.trim() || '');
        const location = this.extractLocationFromTitle(title);
        return {
            id,
            title,
            price,
            rooms,
            size,
            floor,
            hasGarage,
            description,
            url,
            tags,
            location,
        };
    }
    extractLocationFromTitle(title) {
        const parts = title.split(',');
        if (parts.length >= 2) {
            return parts[parts.length - 2].trim();
        }
        return '';
    }
}
exports.PropertyExtractor = PropertyExtractor;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
!function() {
var exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
const investment_analyzer_1 = __webpack_require__(273);
const language_service_1 = __webpack_require__(714);
let analyzer;
let languageService;
async function initializeAnalyzer() {
    languageService = new language_service_1.LanguageService();
    await languageService.initialize();
    analyzer = new investment_analyzer_1.IdealistaInvestmentAnalyzer(languageService);
    analyzer.initialize();
}
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initializeAnalyzer);
}
else {
    initializeAnalyzer();
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('Content script received message:', message);
    debugger;
    if (message.type === "LANGUAGE_CHANGED") {
        console.log('Processing language change to:', message.language);
        languageService.loadLanguageFromStorage().then(() => {
            console.log('Language service updated, current language:', languageService.getLanguage());
            const existingBadges = document.querySelectorAll("[data-property-id]");
            console.log('Removing existing badges:', existingBadges.length);
            existingBadges.forEach((badge) => badge.remove());
            if (analyzer) {
                console.log('Re-initializing analyzer with new language');
                analyzer = new investment_analyzer_1.IdealistaInvestmentAnalyzer(languageService);
                analyzer.initialize();
            }
        });
    }
});

}();
/******/ })()
;
//# sourceMappingURL=content.js.map