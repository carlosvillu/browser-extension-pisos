/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 294:
/***/ (function(__unused_webpack_module, exports) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ConfigService = void 0;
class ConfigService {
    static STORAGE_KEY = 'investmentAnalysisConfig';
    static DEFAULT_CONFIG = {
        expenseConfig: {
            propertyManagementMonthly: 150,
            insuranceMonthly: 50,
            propertyTaxMonthly: 100,
            communityFees: 60,
            vacancyMaintenanceRate: 0.05,
            maintenanceContingencyRate: 0.01,
        },
        mortgageConfig: {
            loanToValueRatio: 0.8,
            managementFeesRate: 0.1,
            interestRate: 2.45,
        },
        profitabilityThresholds: {
            excellent: 6,
            good: 4,
            fair: 2,
        },
        displayOptions: {
            showBadges: true,
            showModal: true,
            showLoadingStates: true,
        },
    };
    async getConfig() {
        try {
            const result = await chrome.storage.sync.get(ConfigService.STORAGE_KEY);
            const storedConfig = result[ConfigService.STORAGE_KEY];
            if (!storedConfig) {
                return ConfigService.DEFAULT_CONFIG;
            }
            const migratedConfig = this.migrateOldConfig(storedConfig);
            return { ...ConfigService.DEFAULT_CONFIG, ...migratedConfig };
        }
        catch (error) {
            console.error('Error loading config:', error);
            return ConfigService.DEFAULT_CONFIG;
        }
    }
    migrateOldConfig(config) {
        if (config.expenseConfig) {
            if (config.expenseConfig.communityFeesWithGarage && !config.expenseConfig.communityFees) {
                const avgCommunity = Math.round(((config.expenseConfig.communityFeesWithGarage || 80) +
                    (config.expenseConfig.communityFeesWithoutGarage || 40)) /
                    2);
                config.expenseConfig.communityFees = avgCommunity;
                delete config.expenseConfig.communityFeesWithGarage;
                delete config.expenseConfig.communityFeesWithoutGarage;
            }
        }
        return config;
    }
    async updateConfig(partialConfig) {
        try {
            const currentConfig = await this.getConfig();
            const newConfig = { ...currentConfig, ...partialConfig };
            await chrome.storage.sync.set({
                [ConfigService.STORAGE_KEY]: newConfig,
            });
        }
        catch (error) {
            console.error('Error saving config:', error);
            throw error;
        }
    }
    async resetToDefaults() {
        try {
            await chrome.storage.sync.set({
                [ConfigService.STORAGE_KEY]: ConfigService.DEFAULT_CONFIG,
            });
        }
        catch (error) {
            console.error('Error resetting config:', error);
            throw error;
        }
    }
}
exports.ConfigService = ConfigService;


/***/ }),

/***/ 714:
/***/ (function(__unused_webpack_module, exports) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.LanguageService = void 0;
class LanguageService {
    static SUPPORTED_LANGUAGES = ['es', 'en', 'fr'];
    static DEFAULT_LANGUAGE = 'en';
    static LOCALE_MAP = {
        'es': 'es-ES',
        'en': 'en-US',
        'fr': 'fr-FR'
    };
    currentLanguage = LanguageService.DEFAULT_LANGUAGE;
    messages = {};
    initialized = false;
    constructor() {
        this.loadMessages();
    }
    async initialize() {
        if (this.initialized)
            return;
        try {
            const result = await chrome.storage.local.get(['language']);
            if (result.language && this.isValidLanguage(result.language)) {
                this.currentLanguage = result.language;
            }
            else {
                const browserLang = this.getBrowserLanguage();
                this.currentLanguage = this.isValidLanguage(browserLang) ? browserLang : LanguageService.DEFAULT_LANGUAGE;
                await chrome.storage.local.set({ language: this.currentLanguage });
            }
        }
        catch (error) {
            console.warn('Error initializing language:', error);
            this.currentLanguage = LanguageService.DEFAULT_LANGUAGE;
        }
        this.initialized = true;
    }
    isValidLanguage(language) {
        return LanguageService.SUPPORTED_LANGUAGES.includes(language);
    }
    static getSupportedLanguages() {
        return [...LanguageService.SUPPORTED_LANGUAGES];
    }
    getBrowserLanguage() {
        if (typeof chrome !== 'undefined' && chrome.i18n && chrome.i18n.getUILanguage) {
            return chrome.i18n.getUILanguage().split('-')[0];
        }
        return navigator.language?.split('-')[0] || 'en';
    }
    loadMessages() {
        this.messages['es'] = {
            appName: 'Análisis de Inversión Inmobiliaria',
            popupTitle: 'Configuración - Análisis de Inversión',
            configurationTitle: 'Configuración de Análisis',
            languageSelector: 'Idioma',
            languageSpanish: 'Español',
            languageEnglish: 'Inglés',
            languageFrench: 'Francés',
            estimatedExpensesTitle: 'Gastos Estimados',
            propertyManagementLabel: 'Gestión inmobiliaria (€)',
            monthlyFixedCost: 'Coste mensual fijo',
            insuranceLabel: 'Seguro (€)',
            ibiLabel: 'IBI (€)',
            vacancyLabel: 'Vacancia (%)',
            rentalPercentage: '% del alquiler',
            repairsLabel: 'Reparaciones y contingencias (%)',
            repairsHelp: '% del alquiler para calentadores, averías, mejoras, etc.',
            communityLabel: 'Comunidad (€)',
            communityHelp: 'Gastos de comunidad mensual',
            mortgageConfigTitle: 'Configuración de Hipoteca',
            financingLabel: 'Financiación (%)',
            priceFinnancedPercentage: '% del precio financiado',
            interestLabel: 'Interés (%)',
            annualTinHelp: 'TIN anual de la hipoteca',
            managementFeesLabel: 'Gastos de gestión (%)',
            managementFeesHelp: '% del precio de compra (notaría, registro, tasación, etc.)',
            profitabilityThresholdsTitle: 'Umbrales de Rentabilidad',
            excellentLabel: 'Excelente (%)',
            goodLabel: 'Buena (%)',
            regularLabel: 'Regular (%)',
            displayOptionsTitle: 'Opciones de Visualización',
            showProfitabilityIndicators: 'Mostrar indicadores de rentabilidad',
            allowDetailsModal: 'Permitir modal de detalles',
            showLoadingStates: 'Mostrar estados de carga',
            restoreButton: 'Restaurar',
            saveButton: 'Guardar',
            errorLoadingConfig: 'Error al cargar la configuración',
            configSavedSuccessfully: 'Configuración guardada correctamente',
            errorSavingConfig: 'Error al guardar la configuración',
            configRestoredSuccessfully: 'Configuración restaurada a valores por defecto',
            errorRestoringConfig: 'Error al restaurar la configuración',
            analyzing: 'Analizando...',
            noRentalData: 'Sin datos de alquiler',
            analysisError: 'Error en análisis',
            netProfitability: 'Rentabilidad Neta:',
            excellentInvestment: 'EXCELENTE INVERSIÓN',
            goodInvestment: 'BUENA INVERSIÓN',
            regularInvestment: 'INVERSIÓN REGULAR',
            badInvestment: 'MALA INVERSIÓN',
            unknownInvestment: 'DESCONOCIDO',
            investmentAnalysisTitle: 'Análisis de Inversión',
            roomsSuffix: ' hab.',
            sizeSuffix: 'm²',
            purchasePrice: 'Precio de compra',
            monthlyRentalEstimate: 'Alquiler estimado mensual',
            monthlyExpensesEstimate: 'Gastos mensuales estimados',
            grossAnnualProfitability: 'Rentabilidad bruta anual',
            netAnnualProfitability: 'Rentabilidad neta anual',
            riskLevel: 'Nivel de riesgo: '
        };
        this.messages['en'] = {
            appName: 'Real Estate Investment Analysis',
            popupTitle: 'Configuration - Investment Analysis',
            configurationTitle: 'Analysis Configuration',
            languageSelector: 'Language',
            languageSpanish: 'Spanish',
            languageEnglish: 'English',
            languageFrench: 'French',
            estimatedExpensesTitle: 'Estimated Expenses',
            propertyManagementLabel: 'Property management (€)',
            monthlyFixedCost: 'Monthly fixed cost',
            insuranceLabel: 'Insurance (€)',
            ibiLabel: 'Property tax (€)',
            vacancyLabel: 'Vacancy (%)',
            rentalPercentage: '% of rental income',
            repairsLabel: 'Repairs and contingencies (%)',
            repairsHelp: '% of rental for heating, breakdowns, improvements, etc.',
            communityLabel: 'Community fees (€)',
            communityHelp: 'Monthly community expenses',
            mortgageConfigTitle: 'Mortgage Configuration',
            financingLabel: 'Financing (%)',
            priceFinnancedPercentage: '% of price financed',
            interestLabel: 'Interest (%)',
            annualTinHelp: 'Annual mortgage interest rate',
            managementFeesLabel: 'Management fees (%)',
            managementFeesHelp: '% of purchase price (notary, registry, appraisal, etc.)',
            profitabilityThresholdsTitle: 'Profitability Thresholds',
            excellentLabel: 'Excellent (%)',
            goodLabel: 'Good (%)',
            regularLabel: 'Regular (%)',
            displayOptionsTitle: 'Display Options',
            showProfitabilityIndicators: 'Show profitability indicators',
            allowDetailsModal: 'Allow details modal',
            showLoadingStates: 'Show loading states',
            restoreButton: 'Restore',
            saveButton: 'Save',
            errorLoadingConfig: 'Error loading configuration',
            configSavedSuccessfully: 'Configuration saved successfully',
            errorSavingConfig: 'Error saving configuration',
            configRestoredSuccessfully: 'Configuration restored to default values',
            errorRestoringConfig: 'Error restoring configuration',
            analyzing: 'Analyzing...',
            noRentalData: 'No rental data',
            analysisError: 'Analysis error',
            netProfitability: 'Net Profitability:',
            excellentInvestment: 'EXCELLENT INVESTMENT',
            goodInvestment: 'GOOD INVESTMENT',
            regularInvestment: 'REGULAR INVESTMENT',
            badInvestment: 'BAD INVESTMENT',
            unknownInvestment: 'UNKNOWN',
            investmentAnalysisTitle: 'Investment Analysis',
            roomsSuffix: ' rooms',
            sizeSuffix: 'm²',
            purchasePrice: 'Purchase price',
            monthlyRentalEstimate: 'Monthly rental estimate',
            monthlyExpensesEstimate: 'Monthly expenses estimate',
            grossAnnualProfitability: 'Gross annual profitability',
            netAnnualProfitability: 'Net annual profitability',
            riskLevel: 'Risk level: '
        };
        this.messages['fr'] = {
            appName: 'Analyse d\'Investissement Immobilier',
            popupTitle: 'Configuration - Analyse d\'Investissement',
            configurationTitle: 'Configuration de l\'Analyse',
            languageSelector: 'Langue',
            languageSpanish: 'Espagnol',
            languageEnglish: 'Anglais',
            languageFrench: 'Français',
            estimatedExpensesTitle: 'Dépenses Estimées',
            propertyManagementLabel: 'Gestion immobilière (€)',
            monthlyFixedCost: 'Coût mensuel fixe',
            insuranceLabel: 'Assurance (€)',
            ibiLabel: 'Taxe foncière (€)',
            vacancyLabel: 'Vacance (%)',
            rentalPercentage: '% du revenu locatif',
            repairsLabel: 'Réparations et contingences (%)',
            repairsHelp: '% du loyer pour chauffage, pannes, améliorations, etc.',
            communityLabel: 'Charges de copropriété (€)',
            communityHelp: 'Charges mensuelles de copropriété',
            mortgageConfigTitle: 'Configuration Hypothécaire',
            financingLabel: 'Financement (%)',
            priceFinnancedPercentage: '% du prix financé',
            interestLabel: 'Intérêt (%)',
            annualTinHelp: 'Taux d\'intérêt annuel de l\'hypothèque',
            managementFeesLabel: 'Frais de gestion (%)',
            managementFeesHelp: '% du prix d\'achat (notaire, registre, évaluation, etc.)',
            profitabilityThresholdsTitle: 'Seuils de Rentabilité',
            excellentLabel: 'Excellent (%)',
            goodLabel: 'Bon (%)',
            regularLabel: 'Régulier (%)',
            displayOptionsTitle: 'Options d\'Affichage',
            showProfitabilityIndicators: 'Afficher les indicateurs de rentabilité',
            allowDetailsModal: 'Permettre le modal de détails',
            showLoadingStates: 'Afficher les états de chargement',
            restoreButton: 'Restaurer',
            saveButton: 'Sauvegarder',
            errorLoadingConfig: 'Erreur lors du chargement de la configuration',
            configSavedSuccessfully: 'Configuration sauvegardée avec succès',
            errorSavingConfig: 'Erreur lors de la sauvegarde de la configuration',
            configRestoredSuccessfully: 'Configuration restaurée aux valeurs par défaut',
            errorRestoringConfig: 'Erreur lors de la restauration de la configuration',
            analyzing: 'Analyse en cours...',
            noRentalData: 'Aucune donnée locative',
            analysisError: 'Erreur d\'analyse',
            netProfitability: 'Rentabilité Nette:',
            excellentInvestment: 'EXCELLENT INVESTISSEMENT',
            goodInvestment: 'BON INVESTISSEMENT',
            regularInvestment: 'INVESTISSEMENT RÉGULIER',
            badInvestment: 'MAUVAIS INVESTISSEMENT',
            unknownInvestment: 'INCONNU',
            investmentAnalysisTitle: 'Analyse d\'Investissement',
            roomsSuffix: ' pièces',
            sizeSuffix: 'm²',
            purchasePrice: 'Prix d\'achat',
            monthlyRentalEstimate: 'Estimation du loyer mensuel',
            monthlyExpensesEstimate: 'Estimation des dépenses mensuelles',
            grossAnnualProfitability: 'Rentabilité annuelle brute',
            netAnnualProfitability: 'Rentabilité annuelle nette',
            riskLevel: 'Niveau de risque: '
        };
    }
    async setLanguage(language) {
        if (this.isValidLanguage(language)) {
            this.currentLanguage = language;
            try {
                await chrome.storage.local.set({ language: language });
                this.notifyLanguageChange(language);
            }
            catch (error) {
                console.warn('Error saving language preference:', error);
            }
        }
    }
    notifyLanguageChange(language) {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const tab = tabs[0];
            if (tab?.id && tab.url) {
                console.log('Current tab URL:', tab.url);
                if (tab.url.includes('idealista.com')) {
                    console.log('Sending language change message to Idealista tab. Language:', language);
                    chrome.tabs.sendMessage(tab.id, {
                        type: 'LANGUAGE_CHANGED',
                        language: language
                    }).then(() => {
                        console.log('Language change message sent successfully');
                    }).catch((error) => {
                        console.warn('Error sending language change message:', error);
                    });
                }
                else {
                    console.log('Not an Idealista tab, skipping message send');
                }
            }
            else {
                console.warn('No active tab found or tab has no URL');
            }
        });
    }
    getLanguage() {
        return this.currentLanguage;
    }
    async loadLanguageFromStorage() {
        try {
            const result = await chrome.storage.local.get(['language']);
            if (result.language && this.isValidLanguage(result.language)) {
                this.currentLanguage = result.language;
            }
        }
        catch (error) {
            console.warn('Error loading language from storage:', error);
        }
    }
    getMessage(key) {
        return this.messages[this.currentLanguage]?.[key] || key;
    }
    formatCurrency(amount, currency = 'EUR') {
        try {
            const locale = LanguageService.LOCALE_MAP[this.currentLanguage] || LanguageService.LOCALE_MAP[LanguageService.DEFAULT_LANGUAGE];
            return new Intl.NumberFormat(locale, {
                style: 'currency',
                currency: currency,
                minimumFractionDigits: 0,
                maximumFractionDigits: 0
            }).format(amount);
        }
        catch (error) {
            console.warn('Error formatting currency:', error);
            return `${amount.toLocaleString()}€`;
        }
    }
    formatPercentage(value, decimals = 2) {
        try {
            const locale = LanguageService.LOCALE_MAP[this.currentLanguage] || LanguageService.LOCALE_MAP[LanguageService.DEFAULT_LANGUAGE];
            return new Intl.NumberFormat(locale, {
                style: 'percent',
                minimumFractionDigits: decimals,
                maximumFractionDigits: decimals
            }).format(value / 100);
        }
        catch (error) {
            console.warn('Error formatting percentage:', error);
            return `${value.toFixed(decimals)}%`;
        }
    }
}
exports.LanguageService = LanguageService;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
!function() {
var exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
const config_service_1 = __webpack_require__(294);
const language_service_1 = __webpack_require__(714);
class PopupController {
    configService;
    languageService;
    form;
    statusMessage;
    constructor() {
        this.configService = new config_service_1.ConfigService();
        this.languageService = new language_service_1.LanguageService();
        this.form = document.getElementById('configForm');
        this.statusMessage = document.getElementById('statusMessage');
        this.initialize();
    }
    async initialize() {
        await this.languageService.initialize();
        await this.setupLanguage();
        this.localizeUI();
        await this.loadConfig();
        this.attachEventListeners();
    }
    async setupLanguage() {
        const currentLang = this.languageService.getLanguage();
        const languageSelector = document.getElementById('languageSelector');
        if (languageSelector) {
            languageSelector.value = currentLang;
        }
    }
    async loadConfig() {
        try {
            const config = await this.configService.getConfig();
            this.populateForm(config);
        }
        catch (error) {
            this.showStatus(this.languageService.getMessage('errorLoadingConfig'), 'error');
        }
    }
    populateForm(config) {
        const elements = {
            propertyManagement: document.getElementById('propertyManagement'),
            insurance: document.getElementById('insurance'),
            propertyTax: document.getElementById('propertyTax'),
            communityFees: document.getElementById('communityFees'),
            vacancyMaintenance: document.getElementById('vacancyMaintenance'),
            maintenanceContingency: document.getElementById('maintenanceContingency'),
            loanToValue: document.getElementById('loanToValue'),
            interestRate: document.getElementById('interestRate'),
            managementFees: document.getElementById('managementFees'),
            excellentThreshold: document.getElementById('excellentThreshold'),
            goodThreshold: document.getElementById('goodThreshold'),
            fairThreshold: document.getElementById('fairThreshold'),
            showBadges: document.getElementById('showBadges'),
            showModal: document.getElementById('showModal'),
            showLoadingStates: document.getElementById('showLoadingStates'),
        };
        elements.propertyManagement.value = config.expenseConfig.propertyManagementMonthly.toString();
        elements.insurance.value = config.expenseConfig.insuranceMonthly.toString();
        elements.propertyTax.value = config.expenseConfig.propertyTaxMonthly.toString();
        elements.communityFees.value = config.expenseConfig.communityFees.toString();
        elements.vacancyMaintenance.value = (config.expenseConfig.vacancyMaintenanceRate * 100).toString();
        elements.maintenanceContingency.value = (config.expenseConfig.maintenanceContingencyRate * 100).toString();
        elements.loanToValue.value = (config.mortgageConfig.loanToValueRatio * 100).toString();
        elements.interestRate.value = config.mortgageConfig.interestRate.toString();
        elements.managementFees.value = (config.mortgageConfig.managementFeesRate * 100).toString();
        elements.excellentThreshold.value = config.profitabilityThresholds.excellent.toString();
        elements.goodThreshold.value = config.profitabilityThresholds.good.toString();
        elements.fairThreshold.value = config.profitabilityThresholds.fair.toString();
        elements.showBadges.checked = config.displayOptions.showBadges;
        elements.showModal.checked = config.displayOptions.showModal;
        elements.showLoadingStates.checked = config.displayOptions.showLoadingStates;
    }
    attachEventListeners() {
        this.form.addEventListener('submit', this.handleSubmit.bind(this));
        const resetButton = document.getElementById('resetButton');
        resetButton?.addEventListener('click', this.handleReset.bind(this));
        const languageSelector = document.getElementById('languageSelector');
        languageSelector?.addEventListener('change', this.handleLanguageChange.bind(this));
    }
    async handleLanguageChange(event) {
        const target = event.target;
        const newLanguage = target.value;
        console.log('Popup: Language changed to:', newLanguage);
        await this.languageService.setLanguage(newLanguage);
        console.log('Popup: Language service updated');
        this.localizeUI();
        console.log('Popup: UI localized');
    }
    async handleSubmit(event) {
        event.preventDefault();
        try {
            const formData = new FormData(this.form);
            const config = this.extractConfigFromForm();
            await this.configService.updateConfig(config);
            this.showStatus(this.languageService.getMessage('configSavedSuccessfully'), 'success');
            setTimeout(() => {
                this.hideStatus();
            }, 3000);
        }
        catch (error) {
            this.showStatus(this.languageService.getMessage('errorSavingConfig'), 'error');
        }
    }
    async handleReset() {
        try {
            await this.configService.resetToDefaults();
            await this.loadConfig();
            this.showStatus(this.languageService.getMessage('configRestoredSuccessfully'), 'success');
            setTimeout(() => {
                this.hideStatus();
            }, 3000);
        }
        catch (error) {
            this.showStatus(this.languageService.getMessage('errorRestoringConfig'), 'error');
        }
    }
    extractConfigFromForm() {
        const getInputValue = (id) => {
            const element = document.getElementById(id);
            return element?.value || '';
        };
        const getCheckboxValue = (id) => {
            const element = document.getElementById(id);
            return element?.checked || false;
        };
        return {
            expenseConfig: {
                propertyManagementMonthly: Number.parseInt(getInputValue('propertyManagement')),
                insuranceMonthly: Number.parseInt(getInputValue('insurance')),
                propertyTaxMonthly: Number.parseInt(getInputValue('propertyTax')),
                communityFees: Number.parseInt(getInputValue('communityFees')),
                vacancyMaintenanceRate: Number.parseFloat(getInputValue('vacancyMaintenance')) / 100,
                maintenanceContingencyRate: Number.parseFloat(getInputValue('maintenanceContingency')) / 100,
            },
            mortgageConfig: {
                loanToValueRatio: Number.parseFloat(getInputValue('loanToValue')) / 100,
                interestRate: Number.parseFloat(getInputValue('interestRate')),
                managementFeesRate: Number.parseFloat(getInputValue('managementFees')) / 100,
            },
            profitabilityThresholds: {
                excellent: Number.parseFloat(getInputValue('excellentThreshold')),
                good: Number.parseFloat(getInputValue('goodThreshold')),
                fair: Number.parseFloat(getInputValue('fairThreshold')),
            },
            displayOptions: {
                showBadges: getCheckboxValue('showBadges'),
                showModal: getCheckboxValue('showModal'),
                showLoadingStates: getCheckboxValue('showLoadingStates'),
            },
        };
    }
    showStatus(message, type) {
        this.statusMessage.textContent = message;
        this.statusMessage.className = `status-message status-${type}`;
        this.statusMessage.style.display = 'block';
    }
    hideStatus() {
        this.statusMessage.style.display = 'none';
    }
    localizeUI() {
        const titleElement = document.getElementById('popup-title');
        if (titleElement) {
            titleElement.textContent = this.languageService.getMessage('popupTitle');
        }
        const elementsToLocalize = document.querySelectorAll('[data-i18n]');
        elementsToLocalize.forEach((element) => {
            const key = element.getAttribute('data-i18n');
            if (key) {
                element.textContent = this.languageService.getMessage(key);
            }
        });
        const elementMappings = {
            'config-header-title': 'configurationTitle',
            'language-selector-label': 'languageSelector',
            'language-option-es': 'languageSpanish',
            'language-option-en': 'languageEnglish',
            'language-option-fr': 'languageFrench',
            'expenses-title': 'estimatedExpensesTitle',
            'property-management-label': 'propertyManagementLabel',
            'property-management-help': 'monthlyFixedCost',
            'insurance-label': 'insuranceLabel',
            'insurance-help': 'monthlyFixedCost',
            'property-tax-label': 'ibiLabel',
            'property-tax-help': 'monthlyFixedCost',
            'vacancy-label': 'vacancyLabel',
            'vacancy-help': 'rentalPercentage',
            'maintenance-contingency-label': 'repairsLabel',
            'maintenance-contingency-help': 'repairsHelp',
            'community-fees-label': 'communityLabel',
            'community-fees-help': 'communityHelp',
            'mortgage-title': 'mortgageConfigTitle',
            'loan-to-value-label': 'financingLabel',
            'loan-to-value-help': 'priceFinnancedPercentage',
            'interest-rate-label': 'interestLabel',
            'interest-rate-help': 'annualTinHelp',
            'management-fees-label': 'managementFeesLabel',
            'management-fees-help': 'managementFeesHelp',
            'profitability-thresholds-title': 'profitabilityThresholdsTitle',
            'excellent-threshold-label': 'excellentLabel',
            'good-threshold-label': 'goodLabel',
            'fair-threshold-label': 'regularLabel',
            'display-options-title': 'displayOptionsTitle',
            'show-badges-label': 'showProfitabilityIndicators',
            'show-modal-label': 'allowDetailsModal',
            'show-loading-states-label': 'showLoadingStates',
            'save-button': 'saveButton',
        };
        Object.entries(elementMappings).forEach(([elementId, messageKey]) => {
            const element = document.getElementById(elementId);
            if (element) {
                element.textContent = this.languageService.getMessage(messageKey);
            }
        });
        const resetButton = document.getElementById('resetButton');
        if (resetButton) {
            resetButton.textContent = this.languageService.getMessage('restoreButton');
        }
    }
}
document.addEventListener('DOMContentLoaded', () => {
    new PopupController();
});

}();
/******/ })()
;
//# sourceMappingURL=popup.js.map