/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
!function() {
var exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
__webpack_unused_export__ = void 0;
class PerformanceMonitor {
    logger;
    metrics = [];
    activeTimers = new Map();
    constructor(logger) {
        this.logger = logger;
    }
    startTimer(operationName) {
        const timerId = `${operationName}-${Date.now()}-${Math.random()}`;
        this.activeTimers.set(timerId, performance.now());
        this.logger.log(`Started timer for ${operationName}`);
        return timerId;
    }
    endTimer(timerId, details) {
        const startTime = this.activeTimers.get(timerId);
        if (!startTime) {
            throw new Error(`Timer ${timerId} not found`);
        }
        const endTime = performance.now();
        const duration = endTime - startTime;
        this.activeTimers.delete(timerId);
        const metric = {
            name: timerId.split('-')[0],
            duration,
            timestamp: Date.now(),
            details,
        };
        this.metrics.push(metric);
        this.logger.log(`${metric.name} completed in ${duration.toFixed(2)}ms`, details);
        return metric;
    }
    async benchmark(operation, operationName, samples) {
        this.logger.log(`Starting benchmark for ${operationName} with ${samples} samples`);
        const durations = [];
        for (let i = 0; i < samples; i++) {
            const timerId = this.startTimer(`${operationName}-benchmark-${i}`);
            try {
                await operation();
                const metric = this.endTimer(timerId);
                durations.push(metric.duration);
                await this.delay(100);
            }
            catch (error) {
                this.logger.error(`Benchmark sample ${i} failed`, error);
                this.activeTimers.delete(timerId);
            }
        }
        if (durations.length === 0) {
            throw new Error(`All benchmark samples failed for ${operationName}`);
        }
        const averageDuration = durations.reduce((sum, d) => sum + d, 0) / durations.length;
        const minDuration = Math.min(...durations);
        const maxDuration = Math.max(...durations);
        const variance = durations.reduce((sum, d) => sum + Math.pow(d - averageDuration, 2), 0) / durations.length;
        const standardDeviation = Math.sqrt(variance);
        const benchmark = {
            operation: operationName,
            samples: durations.length,
            averageDuration,
            minDuration,
            maxDuration,
            standardDeviation,
        };
        this.logger.log(`Benchmark results for ${operationName}:`, benchmark);
        return benchmark;
    }
    getMetrics() {
        return [...this.metrics];
    }
    clearMetrics() {
        this.metrics.length = 0;
        this.activeTimers.clear();
        this.logger.log('Performance metrics cleared');
    }
    delay(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
}
__webpack_unused_export__ = PerformanceMonitor;

}();
/******/ })()
;
//# sourceMappingURL=performance-monitor.js.map