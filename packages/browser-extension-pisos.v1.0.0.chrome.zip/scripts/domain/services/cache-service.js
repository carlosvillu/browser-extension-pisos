/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
!function() {
var exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
__webpack_unused_export__ = void 0;
class RentalDataCacheService {
    logger;
    defaultTTL = 10 * 60 * 1000;
    CACHE_PREFIX = 'rental_cache_';
    constructor(logger) {
        this.logger = logger;
    }
    async get(key) {
        try {
            const cacheKey = this.CACHE_PREFIX + key;
            const result = await chrome.storage.session.get(cacheKey);
            const entry = result[cacheKey];
            if (!entry) {
                return null;
            }
            if (Date.now() - entry.timestamp > entry.ttl) {
                await chrome.storage.session.remove(cacheKey);
                this.logger.log(`Cache entry expired for key: ${key}`);
                return null;
            }
            this.logger.log(`Cache hit for key: ${key}`);
            return entry.data;
        }
        catch (error) {
            this.logger.error(`Error getting cache for key ${key}:`, error);
            return null;
        }
    }
    async set(key, data, ttl = this.defaultTTL) {
        try {
            const cacheKey = this.CACHE_PREFIX + key;
            const entry = {
                data,
                timestamp: Date.now(),
                ttl,
            };
            await chrome.storage.session.set({ [cacheKey]: entry });
            this.logger.log(`Cached data for key: ${key} (TTL: ${ttl}ms)`);
        }
        catch (error) {
            this.logger.error(`Error setting cache for key ${key}:`, error);
        }
    }
    async clear() {
        try {
            const allData = await chrome.storage.session.get(null);
            const cacheKeys = Object.keys(allData).filter((key) => key.startsWith(this.CACHE_PREFIX));
            if (cacheKeys.length > 0) {
                await chrome.storage.session.remove(cacheKeys);
            }
            this.logger.log('Cache cleared');
        }
        catch (error) {
            this.logger.error('Error clearing cache:', error);
        }
    }
    async cleanup() {
        try {
            const allData = await chrome.storage.session.get(null);
            const now = Date.now();
            const expiredKeys = [];
            for (const [key, value] of Object.entries(allData)) {
                if (key.startsWith(this.CACHE_PREFIX)) {
                    const entry = value;
                    if (now - entry.timestamp > entry.ttl) {
                        expiredKeys.push(key);
                    }
                }
            }
            if (expiredKeys.length > 0) {
                await chrome.storage.session.remove(expiredKeys);
                this.logger.log(`Cleaned up ${expiredKeys.length} expired cache entries`);
            }
        }
        catch (error) {
            this.logger.error('Error during cache cleanup:', error);
        }
    }
}
__webpack_unused_export__ = RentalDataCacheService;

}();
/******/ })()
;
//# sourceMappingURL=cache-service.js.map