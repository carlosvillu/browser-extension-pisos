/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
!function() {
var exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
__webpack_unused_export__ = void 0;
class CrossReferenceUrlGenerator {
    logger;
    constructor(logger) {
        this.logger = logger;
    }
    generateRentalUrl(location, property) {
        const baseUrl = 'https://www.idealista.com/alquiler-viviendas';
        return this.buildUrl(baseUrl, location, property);
    }
    generateSaleUrl(location, property) {
        const baseUrl = 'https://www.idealista.com/venta-viviendas';
        return this.buildUrl(baseUrl, location, property);
    }
    buildUrl(baseUrl, location, property) {
        if (!location) {
            this.logger.error('No location provided for URL generation');
            return `${baseUrl}/`;
        }
        let url = `${baseUrl}/${location}/`;
        const params = new URLSearchParams();
        if (property.rooms && property.rooms > 0) {
            params.append('habitaciones', property.rooms.toString());
        }
        if (property.size && property.size > 0) {
            const minSize = Math.max(1, property.size - 20);
            const maxSize = property.size + 20;
            params.append('superficie', `${minSize}-${maxSize}`);
        }
        const paramString = params.toString();
        if (paramString) {
            url += `?${paramString}`;
        }
        return url;
    }
}
__webpack_unused_export__ = CrossReferenceUrlGenerator;

}();
/******/ })()
;
//# sourceMappingURL=url-generator.js.map