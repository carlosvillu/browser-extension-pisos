/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
!function() {
var exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
__webpack_unused_export__ = void 0;
class PropertyExtractor {
    logger;
    constructor(logger) {
        this.logger = logger;
    }
    extractPropertiesFromPage() {
        const properties = [];
        const propertyElements = document.querySelectorAll('article.item[data-element-id]');
        this.logger.log(`Found ${propertyElements.length} property elements on page`);
        propertyElements.forEach((element) => {
            try {
                const property = this.extractPropertyData(element);
                if (property) {
                    properties.push(property);
                }
            }
            catch (error) {
                this.logger.error('Error extracting property data', error);
            }
        });
        return properties;
    }
    extractPropertiesFromDocument(doc) {
        const properties = [];
        const propertyElements = doc.querySelectorAll('article.item[data-element-id]');
        propertyElements.forEach((element) => {
            try {
                const property = this.extractPropertyDataFromElement(element);
                if (property) {
                    properties.push(property);
                }
            }
            catch (error) {
                this.logger.error('Error extracting property data from element', error);
            }
        });
        return properties;
    }
    extractPropertyData(element) {
        return this.extractPropertyDataFromElement(element);
    }
    extractPropertyDataFromElement(element) {
        const id = element.getAttribute('data-element-id');
        if (!id)
            return null;
        const priceElement = element.querySelector('.item-price');
        const priceText = priceElement?.textContent?.replace(/[€\s]/g, '').replace('.', '') || '0';
        const price = Number.parseInt(priceText, 10) || 0;
        const linkElement = element.querySelector('.item-link');
        const title = linkElement?.textContent?.trim() || '';
        const url = linkElement?.href || '';
        const details = element.querySelectorAll('.item-detail');
        let rooms = null;
        let size = null;
        let floor = null;
        details.forEach((detail) => {
            const text = detail.textContent?.trim() || '';
            if (text.includes('hab.')) {
                const roomMatch = text.match(/(\d+)\s*hab\./);
                rooms = roomMatch ? Number.parseInt(roomMatch[1], 10) : null;
            }
            else if (text.includes('m²')) {
                const sizeMatch = text.match(/(\d+)\s*m²/);
                size = sizeMatch ? Number.parseInt(sizeMatch[1], 10) : null;
            }
            else if (text.includes('Planta') || text.includes('Bajo')) {
                floor = text;
            }
        });
        const hasGarage = !!element.querySelector('.item-parking');
        const descriptionElement = element.querySelector('.item-description .ellipsis');
        const description = descriptionElement?.textContent?.trim() || '';
        const tagElements = element.querySelectorAll('.listing-tags');
        const tags = Array.from(tagElements).map((tag) => tag.textContent?.trim() || '');
        const location = this.extractLocationFromTitle(title);
        return {
            id,
            title,
            price,
            rooms,
            size,
            floor,
            hasGarage,
            description,
            url,
            tags,
            location,
        };
    }
    extractLocationFromTitle(title) {
        const parts = title.split(',');
        if (parts.length >= 2) {
            return parts[parts.length - 2].trim();
        }
        return '';
    }
}
__webpack_unused_export__ = PropertyExtractor;

}();
/******/ })()
;
//# sourceMappingURL=property-extractor.js.map