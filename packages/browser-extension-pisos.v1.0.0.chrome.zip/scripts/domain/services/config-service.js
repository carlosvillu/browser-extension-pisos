/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
!function() {
var exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
__webpack_unused_export__ = void 0;
class ConfigService {
    static STORAGE_KEY = 'investmentAnalysisConfig';
    static DEFAULT_CONFIG = {
        expenseConfig: {
            propertyManagementMonthly: 150,
            insuranceMonthly: 50,
            propertyTaxMonthly: 100,
            communityFees: 60,
            vacancyMaintenanceRate: 0.05,
            maintenanceContingencyRate: 0.01,
        },
        mortgageConfig: {
            loanToValueRatio: 0.8,
            managementFeesRate: 0.1,
            interestRate: 2.45,
        },
        profitabilityThresholds: {
            excellent: 6,
            good: 4,
            fair: 2,
        },
        displayOptions: {
            showBadges: true,
            showModal: true,
            showLoadingStates: true,
        },
    };
    async getConfig() {
        try {
            const result = await chrome.storage.sync.get(ConfigService.STORAGE_KEY);
            const storedConfig = result[ConfigService.STORAGE_KEY];
            if (!storedConfig) {
                return ConfigService.DEFAULT_CONFIG;
            }
            const migratedConfig = this.migrateOldConfig(storedConfig);
            return { ...ConfigService.DEFAULT_CONFIG, ...migratedConfig };
        }
        catch (error) {
            console.error('Error loading config:', error);
            return ConfigService.DEFAULT_CONFIG;
        }
    }
    migrateOldConfig(config) {
        if (config.expenseConfig) {
            if (config.expenseConfig.communityFeesWithGarage && !config.expenseConfig.communityFees) {
                const avgCommunity = Math.round(((config.expenseConfig.communityFeesWithGarage || 80) +
                    (config.expenseConfig.communityFeesWithoutGarage || 40)) /
                    2);
                config.expenseConfig.communityFees = avgCommunity;
                delete config.expenseConfig.communityFeesWithGarage;
                delete config.expenseConfig.communityFeesWithoutGarage;
            }
        }
        return config;
    }
    async updateConfig(partialConfig) {
        try {
            const currentConfig = await this.getConfig();
            const newConfig = { ...currentConfig, ...partialConfig };
            await chrome.storage.sync.set({
                [ConfigService.STORAGE_KEY]: newConfig,
            });
        }
        catch (error) {
            console.error('Error saving config:', error);
            throw error;
        }
    }
    async resetToDefaults() {
        try {
            await chrome.storage.sync.set({
                [ConfigService.STORAGE_KEY]: ConfigService.DEFAULT_CONFIG,
            });
        }
        catch (error) {
            console.error('Error resetting config:', error);
            throw error;
        }
    }
}
__webpack_unused_export__ = ConfigService;

}();
/******/ })()
;
//# sourceMappingURL=config-service.js.map