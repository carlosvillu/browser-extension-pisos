/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 294:
/***/ (function(__unused_webpack_module, exports) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ConfigService = void 0;
class ConfigService {
    static STORAGE_KEY = 'investmentAnalysisConfig';
    static DEFAULT_CONFIG = {
        expenseConfig: {
            propertyManagementMonthly: 150,
            insuranceMonthly: 50,
            propertyTaxMonthly: 100,
            communityFees: 60,
            vacancyMaintenanceRate: 0.05,
            maintenanceContingencyRate: 0.01,
        },
        mortgageConfig: {
            loanToValueRatio: 0.8,
            managementFeesRate: 0.1,
            interestRate: 2.45,
        },
        profitabilityThresholds: {
            excellent: 6,
            good: 4,
            fair: 2,
        },
        displayOptions: {
            showBadges: true,
            showModal: true,
            showLoadingStates: true,
        },
    };
    async getConfig() {
        try {
            const result = await chrome.storage.sync.get(ConfigService.STORAGE_KEY);
            const storedConfig = result[ConfigService.STORAGE_KEY];
            if (!storedConfig) {
                return ConfigService.DEFAULT_CONFIG;
            }
            const migratedConfig = this.migrateOldConfig(storedConfig);
            return { ...ConfigService.DEFAULT_CONFIG, ...migratedConfig };
        }
        catch (error) {
            console.error('Error loading config:', error);
            return ConfigService.DEFAULT_CONFIG;
        }
    }
    migrateOldConfig(config) {
        if (config.expenseConfig) {
            if (config.expenseConfig.communityFeesWithGarage && !config.expenseConfig.communityFees) {
                const avgCommunity = Math.round(((config.expenseConfig.communityFeesWithGarage || 80) +
                    (config.expenseConfig.communityFeesWithoutGarage || 40)) /
                    2);
                config.expenseConfig.communityFees = avgCommunity;
                delete config.expenseConfig.communityFeesWithGarage;
                delete config.expenseConfig.communityFeesWithoutGarage;
            }
        }
        return config;
    }
    async updateConfig(partialConfig) {
        try {
            const currentConfig = await this.getConfig();
            const newConfig = { ...currentConfig, ...partialConfig };
            await chrome.storage.sync.set({
                [ConfigService.STORAGE_KEY]: newConfig,
            });
        }
        catch (error) {
            console.error('Error saving config:', error);
            throw error;
        }
    }
    async resetToDefaults() {
        try {
            await chrome.storage.sync.set({
                [ConfigService.STORAGE_KEY]: ConfigService.DEFAULT_CONFIG,
            });
        }
        catch (error) {
            console.error('Error resetting config:', error);
            throw error;
        }
    }
}
exports.ConfigService = ConfigService;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
!function() {
var exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
__webpack_unused_export__ = void 0;
const config_service_1 = __webpack_require__(294);
class ProfitabilityCalculator {
    logger;
    config;
    DEFAULT_CONFIG = {
        propertyManagementRate: 0.09,
        insuranceRate: 0.002,
        propertyTaxRate: 0.007,
        communityFeesWithGarage: 80,
        communityFeesWithoutGarage: 40,
        vacancyMaintenanceRate: 0.05,
    };
    configService;
    userConfig;
    constructor(logger, config = {}) {
        this.logger = logger;
        this.config = config;
        this.config = { ...this.DEFAULT_CONFIG, ...config };
        this.configService = new config_service_1.ConfigService();
    }
    async calculateProfitability(property, rentalData) {
        if (!this.userConfig) {
            this.userConfig = await this.configService.getConfig();
        }
        const activeConfig = this.userConfig.expenseConfig;
        const monthlyRent = rentalData.averagePrice;
        const annualRent = monthlyRent * 12;
        const purchasePrice = property.price;
        const grossYield = (annualRent / purchasePrice) * 100;
        const monthlyExpenses = this.calculateMonthlyExpenses(property, monthlyRent, activeConfig);
        const annualExpenses = monthlyExpenses * 12;
        const netAnnualRent = annualRent - annualExpenses;
        const netYield = Math.max(0, (netAnnualRent / purchasePrice) * 100);
        const { recommendation, riskLevel } = this.evaluateInvestment(grossYield, netYield, rentalData.sampleSize);
        this.logger.log(`Profitability calculation for ${property.id}: Gross ${grossYield.toFixed(2)}%, Net ${netYield.toFixed(2)}%`);
        return {
            propertyId: property.id,
            purchasePrice,
            estimatedRent: monthlyRent,
            grossYield: Math.round(grossYield * 100) / 100,
            netYield: Math.round(netYield * 100) / 100,
            monthlyExpenses,
            recommendation,
            riskLevel,
        };
    }
    calculateMonthlyExpenses(property, monthlyRent, expenseConfig) {
        let expenses = 0;
        expenses += expenseConfig.propertyManagementMonthly || 150;
        expenses += expenseConfig.insuranceMonthly || 50;
        expenses += expenseConfig.propertyTaxMonthly || 100;
        expenses += expenseConfig.communityFees || 60;
        expenses += monthlyRent * (expenseConfig.vacancyMaintenanceRate || 0.05);
        expenses += monthlyRent * (expenseConfig.maintenanceContingencyRate || 0.01);
        return Math.round(expenses);
    }
    evaluateInvestment(grossYield, netYield, sampleSize) {
        let recommendation;
        let riskLevel;
        const thresholds = this.userConfig?.profitabilityThresholds || {
            excellent: 6,
            good: 4,
            fair: 2,
        };
        if (netYield >= thresholds.excellent) {
            recommendation = 'excellent';
        }
        else if (netYield >= thresholds.good) {
            recommendation = 'good';
        }
        else if (netYield >= thresholds.fair) {
            recommendation = 'fair';
        }
        else {
            recommendation = 'poor';
        }
        if (sampleSize < 3) {
            riskLevel = 'high';
        }
        else if (grossYield > 8 || netYield < 1) {
            riskLevel = 'high';
        }
        else if (netYield >= 3 && grossYield <= 7) {
            riskLevel = 'low';
        }
        else {
            riskLevel = 'medium';
        }
        return { recommendation, riskLevel };
    }
}
__webpack_unused_export__ = ProfitabilityCalculator;

}();
/******/ })()
;
//# sourceMappingURL=profitability-calculator.js.map