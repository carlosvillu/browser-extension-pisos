/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
!function() {
var exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
__webpack_unused_export__ = void 0;
class RentalDataAnalyzer {
    logger;
    propertyExtractor;
    cacheService;
    errorHandler;
    constructor(logger, propertyExtractor, cacheService, errorHandler) {
        this.logger = logger;
        this.propertyExtractor = propertyExtractor;
        this.cacheService = cacheService;
        this.errorHandler = errorHandler;
    }
    async fetchRentalData(rentalUrl) {
        const cacheKey = this.createCacheKey(rentalUrl);
        const cachedData = await this.cacheService.get(cacheKey);
        if (cachedData) {
            return cachedData;
        }
        return this.fetchWithRetry(rentalUrl, cacheKey, 1);
    }
    async fetchWithRetry(rentalUrl, cacheKey, attempt) {
        const context = {
            operation: 'fetchRentalData',
            url: rentalUrl,
        };
        try {
            this.logger.log(`Fetching rental data (attempt ${attempt}): ${rentalUrl}`);
            const response = await fetch(rentalUrl, {
                method: 'GET',
                headers: {
                    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'es-ES,es;q=0.5',
                    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
                },
            });
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: Failed to fetch rental data`);
            }
            const html = await response.text();
            const data = this.parseRentalDataFromHtml(html);
            if (data) {
                await this.cacheService.set(cacheKey, data);
            }
            return data;
        }
        catch (error) {
            this.errorHandler.handleError(error, context);
            if (this.errorHandler.shouldRetry(error, attempt)) {
                const delay = this.errorHandler.getRetryDelay(attempt);
                this.logger.log(`Retrying in ${delay}ms (attempt ${attempt + 1})`);
                await this.delay(delay);
                return this.fetchWithRetry(rentalUrl, cacheKey, attempt + 1);
            }
            return null;
        }
    }
    createCacheKey(url) {
        try {
            const urlObj = new URL(url);
            return `${urlObj.pathname}${urlObj.search}`;
        }
        catch {
            return url;
        }
    }
    delay(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
    parseRentalDataFromHtml(html) {
        try {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const properties = this.propertyExtractor.extractPropertiesFromDocument(doc);
            if (properties.length === 0) {
                this.logger.log('No rental properties found in response');
                return null;
            }
            const prices = properties
                .map((p) => p.price)
                .filter((price) => price > 0)
                .sort((a, b) => a - b);
            if (prices.length === 0) {
                this.logger.log('No valid prices found in rental properties');
                return null;
            }
            const averagePrice = prices.reduce((sum, price) => sum + price, 0) / prices.length;
            const minPrice = prices[0];
            const maxPrice = prices[prices.length - 1];
            this.logger.log(`Rental analysis: ${prices.length} properties, avg: ${averagePrice}€`);
            return {
                averagePrice: Math.round(averagePrice),
                minPrice,
                maxPrice,
                sampleSize: prices.length,
                properties,
            };
        }
        catch (error) {
            this.logger.error('Error parsing rental data from HTML', error);
            return null;
        }
    }
}
__webpack_unused_export__ = RentalDataAnalyzer;

}();
/******/ })()
;
//# sourceMappingURL=rental-data-analyzer.js.map