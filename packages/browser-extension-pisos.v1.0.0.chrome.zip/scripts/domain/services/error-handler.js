/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
!function() {
var exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
__webpack_unused_export__ = void 0;
class RobustErrorHandler {
    logger;
    maxRetries = 3;
    baseDelay = 1000;
    errorCounts = new Map();
    constructor(logger) {
        this.logger = logger;
    }
    handleError(error, context) {
        const errorKey = `${context.operation}-${error.name}`;
        const currentCount = this.errorCounts.get(errorKey) || 0;
        this.errorCounts.set(errorKey, currentCount + 1);
        this.logger.error(`Error in ${context.operation}`, {
            error: error.message,
            stack: error.stack,
            context,
            errorCount: currentCount + 1,
        });
        if (error.message.includes('fetch')) {
            this.logger.error('Network error detected', {
                url: context.url,
                propertyId: context.propertyId,
            });
        }
        else if (error.message.includes('parse') || error.message.includes('DOM')) {
            this.logger.error('Parsing error detected', {
                operation: context.operation,
                additionalData: context.additionalData,
            });
        }
    }
    shouldRetry(error, attemptCount) {
        if (attemptCount >= this.maxRetries) {
            return false;
        }
        if (error.message.includes('fetch') || error.message.includes('network') || error.message.includes('timeout')) {
            return true;
        }
        if (error.message.includes('500') ||
            error.message.includes('502') ||
            error.message.includes('503') ||
            error.message.includes('504')) {
            return true;
        }
        return false;
    }
    getRetryDelay(attemptCount) {
        const delay = this.baseDelay * Math.pow(2, attemptCount);
        const jitter = Math.random() * 0.1 * delay;
        return delay + jitter;
    }
    getErrorStats() {
        return Object.fromEntries(this.errorCounts);
    }
    clearErrorStats() {
        this.errorCounts.clear();
        this.logger.log('Error statistics cleared');
    }
}
__webpack_unused_export__ = RobustErrorHandler;

}();
/******/ })()
;
//# sourceMappingURL=error-handler.js.map