/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
!function() {
var exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
__webpack_unused_export__ = void 0;
class UrlAnalyzer {
    logger;
    constructor(logger) {
        this.logger = logger;
    }
    analyzeCurrentPage() {
        const url = new URL(window.location.href);
        return this.analyzeUrl(url);
    }
    analyzeUrl(url) {
        const pathname = url.pathname;
        const searchParams = url.searchParams;
        let searchType = null;
        if (pathname.includes('/venta-viviendas/')) {
            searchType = 'venta';
        }
        else if (pathname.includes('/alquiler-viviendas/')) {
            searchType = 'alquiler';
        }
        const location = this.extractLocationFromUrl(pathname);
        const hasFilters = searchParams.toString().length > 0;
        const isIdealista = url.hostname === 'www.idealista.com' &&
            (pathname.includes('/venta-viviendas/') || pathname.includes('/alquiler-viviendas/'));
        const result = {
            isIdealista,
            searchType,
            location,
            hasFilters,
        };
        this.logger.log('URL Analysis:', result);
        return result;
    }
    isIdealistaPropertyPage() {
        const hostname = window.location.hostname;
        const pathname = window.location.pathname;
        return (hostname === 'www.idealista.com' &&
            (pathname.includes('/venta-viviendas/') || pathname.includes('/alquiler-viviendas/')));
    }
    extractLocationFromUrl(pathname) {
        const match = pathname.match(/\/(venta|alquiler)-viviendas\/([^/]+)/);
        return match ? match[2] : null;
    }
}
__webpack_unused_export__ = UrlAnalyzer;

}();
/******/ })()
;
//# sourceMappingURL=url-analyzer.js.map