/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
!function() {
var exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
__webpack_unused_export__ = void 0;
class IntersectionSimpleLazyLoader {
    logger;
    observer = null;
    processedElements = new Set();
    constructor(logger) {
        this.logger = logger;
    }
    observeElements(elements, callback) {
        if (!this.observer) {
            this.observer = new IntersectionObserver((entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting && !this.processedElements.has(entry.target)) {
                        this.processedElements.add(entry.target);
                        callback(entry.target);
                        this.observer.unobserve(entry.target);
                    }
                });
            }, {
                rootMargin: '100px',
                threshold: 0.1,
            });
        }
        elements.forEach((element) => {
            if (!this.processedElements.has(element)) {
                this.observer.observe(element);
            }
        });
    }
    disconnect() {
        if (this.observer) {
            this.observer.disconnect();
            this.processedElements.clear();
            this.observer = null;
        }
    }
}
__webpack_unused_export__ = IntersectionSimpleLazyLoader;

}();
/******/ })()
;
//# sourceMappingURL=simple-lazy-loader.js.map