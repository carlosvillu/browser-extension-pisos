/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
!function() {
var exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
__webpack_unused_export__ = void 0;
class ContentCacheService {
    logger;
    constructor(logger) {
        this.logger = logger;
    }
    async get(key) {
        try {
            const response = await chrome.runtime.sendMessage({
                type: 'CACHE_GET',
                key,
            });
            if (!response.success) {
                throw new Error(response.error);
            }
            return response.data;
        }
        catch (error) {
            this.logger.error(`Error getting cache for key ${key}:`, error);
            return null;
        }
    }
    async set(key, data, ttl) {
        try {
            const response = await chrome.runtime.sendMessage({
                type: 'CACHE_SET',
                key,
                data,
                ttl,
            });
            if (!response.success) {
                throw new Error(response.error);
            }
        }
        catch (error) {
            this.logger.error(`Error setting cache for key ${key}:`, error);
        }
    }
    async clear() {
        try {
            const response = await chrome.runtime.sendMessage({
                type: 'CACHE_CLEAR',
            });
            if (!response.success) {
                throw new Error(response.error);
            }
        }
        catch (error) {
            this.logger.error('Error clearing cache:', error);
        }
    }
    async cleanup() {
        try {
            const response = await chrome.runtime.sendMessage({
                type: 'CACHE_CLEANUP',
            });
            if (!response.success) {
                throw new Error(response.error);
            }
        }
        catch (error) {
            this.logger.error('Error during cache cleanup:', error);
        }
    }
}
__webpack_unused_export__ = ContentCacheService;

}();
/******/ })()
;
//# sourceMappingURL=content-cache-service.js.map