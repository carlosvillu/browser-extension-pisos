/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
!function() {
var exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
__webpack_unused_export__ = void 0;
class DOMOptimizer {
    logger;
    updateQueue = [];
    isScheduled = false;
    constructor(logger) {
        this.logger = logger;
    }
    batchDOMUpdates(updates) {
        requestAnimationFrame(() => {
            const measurements = [];
            updates.forEach((update, index) => {
                try {
                    if (update.name === 'readMeasurements') {
                        measurements[index] = update();
                    }
                }
                catch (error) {
                    this.logger.error('Error in DOM read phase', error);
                }
            });
            updates.forEach((update, index) => {
                try {
                    if (update.name !== 'readMeasurements') {
                        update();
                    }
                }
                catch (error) {
                    this.logger.error('Error in DOM write phase', error);
                }
            });
            this.logger.log(`Batched ${updates.length} DOM updates`);
        });
    }
    measureElement(element) {
        return element.getBoundingClientRect();
    }
    scheduleUpdate(callback) {
        this.updateQueue.push(callback);
        if (!this.isScheduled) {
            this.isScheduled = true;
            requestAnimationFrame(() => {
                const updates = [...this.updateQueue];
                this.updateQueue.length = 0;
                this.isScheduled = false;
                this.batchDOMUpdates(updates);
            });
        }
    }
}
__webpack_unused_export__ = DOMOptimizer;

}();
/******/ })()
;
//# sourceMappingURL=dom-optimizer.js.map