/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
!function() {
var exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
__webpack_unused_export__ = void 0;
class I18nService {
    static instance;
    currentLanguage = 'en';
    constructor() {
        this.initializeLanguage();
    }
    static getInstance() {
        if (!I18nService.instance) {
            I18nService.instance = new I18nService();
        }
        return I18nService.instance;
    }
    async initializeLanguage() {
        try {
            const result = await chrome.storage.local.get(['userLanguage']);
            if (result.userLanguage && (result.userLanguage === 'es' || result.userLanguage === 'en')) {
                this.currentLanguage = result.userLanguage;
            }
            else {
                const browserLang = this.getBrowserLanguage();
                this.currentLanguage = (browserLang === 'es') ? 'es' : 'en';
                await chrome.storage.local.set({ userLanguage: this.currentLanguage });
            }
        }
        catch (error) {
            console.warn('Error initializing language:', error);
            this.currentLanguage = 'en';
        }
    }
    getBrowserLanguage() {
        if (typeof chrome !== 'undefined' && chrome.i18n && chrome.i18n.getUILanguage) {
            return chrome.i18n.getUILanguage().split('-')[0];
        }
        return navigator.language?.split('-')[0] || 'en';
    }
    async setLanguage(language) {
        if (language === 'es' || language === 'en') {
            this.currentLanguage = language;
            try {
                await chrome.storage.local.set({ userLanguage: language });
            }
            catch (error) {
                console.warn('Error saving language preference:', error);
            }
        }
    }
    async getLanguage() {
        if (!this.currentLanguage) {
            await this.initializeLanguage();
        }
        return this.currentLanguage;
    }
    getMessage(key, substitutions) {
        if (typeof chrome !== 'undefined' && chrome.i18n && chrome.i18n.getMessage) {
            return chrome.i18n.getMessage(key, substitutions) || key;
        }
        return key;
    }
    formatCurrency(amount, currency = 'EUR') {
        try {
            if (typeof chrome !== 'undefined' && chrome.i18n && chrome.i18n.getUILanguage) {
                const locale = chrome.i18n.getUILanguage();
                return new Intl.NumberFormat(locale, {
                    style: 'currency',
                    currency: currency,
                    minimumFractionDigits: 0,
                    maximumFractionDigits: 0,
                }).format(amount);
            }
        }
        catch (error) {
            console.warn('Error formatting currency:', error);
        }
        return `${amount.toLocaleString()}€`;
    }
    formatPercentage(value, decimals = 2) {
        try {
            if (typeof chrome !== 'undefined' && chrome.i18n && chrome.i18n.getUILanguage) {
                const locale = chrome.i18n.getUILanguage();
                return new Intl.NumberFormat(locale, {
                    style: 'percent',
                    minimumFractionDigits: decimals,
                    maximumFractionDigits: decimals,
                }).format(value / 100);
            }
        }
        catch (error) {
            console.warn('Error formatting percentage:', error);
        }
        return `${value.toFixed(decimals)}%`;
    }
    getCurrentLanguage() {
        if (typeof chrome !== 'undefined' && chrome.i18n && chrome.i18n.getUILanguage) {
            return chrome.i18n.getUILanguage().split('-')[0];
        }
        return 'es';
    }
}
__webpack_unused_export__ = I18nService;

}();
/******/ })()
;
//# sourceMappingURL=i18n-service.js.map