(()=>{"use strict";var e,o={892:function(e,o){var t=this&&this.__spreadArray||function(e,o,t){if(t||2===arguments.length)for(var n,r=0,i=o.length;r<i;r++)!n&&r in o||(n||(n=Array.prototype.slice.call(o,0,r)),n[r]=o[r]);return e.concat(n||Array.prototype.slice.call(o))};Object.defineProperty(o,"__esModule",{value:!0});var n=function(){function e(e){var o=void 0===e?{}:e,t=o.quiet,n=void 0!==t&&t,r=o.extension;this.quiet=n,this.browser=r,this.host="localhost",this.port=parseInt("35729",10),this.reconnectTime=parseInt("3000",10),this.fileRegex=/[^"]*\.[a-zA-Z]+/g}return e.prototype.log=function(e){for(var o=[],n=1;n<arguments.length;n++)o[n-1]=arguments[n];this.quiet||console.log.apply(console,t(["%cwebpack-webextension-plugin: ".concat(e),"color: gray;"],o,!1))},e.prototype.getManifestFileDeps=function(){var e=this.browser.runtime.getManifest();return JSON.stringify(e).match(this.fileRegex)||[]},e.prototype.handleServerMessage=function(e){var o=e.action,t=e.changedFiles;"reload"===o?this.smartReloadExtension(t):this.log("Unknown action: %s",o)},e.prototype.smartReloadExtension=function(e){return this.log("Reloading..."),e?e.some((function(e){return"manifest.json"===e}))?(this.log("Full Reload (manifest.json changed)"),void this.browser.runtime.reload()):e.some((function(e){return/^_locales\//.test(e)}))?(this.log("Full Reload (locales changed)"),void this.browser.runtime.reload()):this.getManifestFileDeps().some((function(o){return e.includes(o)}))?(this.log("Full Reload (manifest deps changed)"),void this.browser.runtime.reload()):(this.browser.tabs.reload(),void this.browser.extension.getViews().map((function(e){return e.location.reload()}))):(this.log("Full Reload (no changed files)"),void this.browser.runtime.reload())},e.prototype.debounce=function(e,o){var t,n=this;return void 0===o&&(o=300),function(){for(var r=[],i=0;i<arguments.length;i++)r[i]=arguments[i];clearTimeout(t),t=setTimeout((function(){e.apply(n,r)}),o)}},e.prototype.connect=function(){var e=this,o=new WebSocket("ws://".concat(this.host,":").concat(this.port));o.onopen=function(){e.log("Connected")},o.onmessage=function(o){var t;try{t=JSON.parse(o.data)}catch(o){e.log("Could not parse server payload")}e.handleServerMessage(t)},o.onerror=function(){e.log("Connection error.")},o.onclose=function(){e.log("Connection lost. Reconnecting in %ss'",e.reconnectTime/1e3),e.debounce(e.connect,e.reconnectTime)}},e}();o.default=n}},t={};function n(e){var r=t[e];if(void 0!==r)return r.exports;var i=t[e]={exports:{}};return o[e].call(i.exports,i,i.exports,n),i.exports}n.n=e=>{var o=e&&e.__esModule?()=>e.default:()=>e;return n.d(o,{a:o}),o},n.d=(e,o)=>{for(var t in o)n.o(o,t)&&!n.o(e,t)&&Object.defineProperty(e,t,{enumerable:!0,get:o[t]})},n.o=(e,o)=>Object.prototype.hasOwnProperty.call(e,o),e=n(892),new(n.n(e)())({extension:"undefined"!=typeof browser?browser:chrome}).connect()})();
/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 279:
/***/ (function(__unused_webpack_module, exports) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.RentalDataCacheService = void 0;
class RentalDataCacheService {
    logger;
    defaultTTL = 10 * 60 * 1000;
    CACHE_PREFIX = 'rental_cache_';
    constructor(logger) {
        this.logger = logger;
    }
    async get(key) {
        try {
            const cacheKey = this.CACHE_PREFIX + key;
            const result = await chrome.storage.session.get(cacheKey);
            const entry = result[cacheKey];
            if (!entry) {
                return null;
            }
            if (Date.now() - entry.timestamp > entry.ttl) {
                await chrome.storage.session.remove(cacheKey);
                this.logger.log(`Cache entry expired for key: ${key}`);
                return null;
            }
            this.logger.log(`Cache hit for key: ${key}`);
            return entry.data;
        }
        catch (error) {
            this.logger.error(`Error getting cache for key ${key}:`, error);
            return null;
        }
    }
    async set(key, data, ttl = this.defaultTTL) {
        try {
            const cacheKey = this.CACHE_PREFIX + key;
            const entry = {
                data,
                timestamp: Date.now(),
                ttl,
            };
            await chrome.storage.session.set({ [cacheKey]: entry });
            this.logger.log(`Cached data for key: ${key} (TTL: ${ttl}ms)`);
        }
        catch (error) {
            this.logger.error(`Error setting cache for key ${key}:`, error);
        }
    }
    async clear() {
        try {
            const allData = await chrome.storage.session.get(null);
            const cacheKeys = Object.keys(allData).filter((key) => key.startsWith(this.CACHE_PREFIX));
            if (cacheKeys.length > 0) {
                await chrome.storage.session.remove(cacheKeys);
            }
            this.logger.log('Cache cleared');
        }
        catch (error) {
            this.logger.error('Error clearing cache:', error);
        }
    }
    async cleanup() {
        try {
            const allData = await chrome.storage.session.get(null);
            const now = Date.now();
            const expiredKeys = [];
            for (const [key, value] of Object.entries(allData)) {
                if (key.startsWith(this.CACHE_PREFIX)) {
                    const entry = value;
                    if (now - entry.timestamp > entry.ttl) {
                        expiredKeys.push(key);
                    }
                }
            }
            if (expiredKeys.length > 0) {
                await chrome.storage.session.remove(expiredKeys);
                this.logger.log(`Cleaned up ${expiredKeys.length} expired cache entries`);
            }
        }
        catch (error) {
            this.logger.error('Error during cache cleanup:', error);
        }
    }
}
exports.RentalDataCacheService = RentalDataCacheService;


/***/ }),

/***/ 530:
/***/ (function(__unused_webpack_module, exports) {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Logger = void 0;
class Logger {
    context;
    constructor(context) {
        this.context = context;
    }
    log(message, data) {
        const timestamp = new Date().toISOString();
        const prefix = `[${timestamp}][${this.context}]`;
        if (data) {
            console.log(`${prefix} ${message}`, data);
        }
        else {
            console.log(`${prefix} ${message}`);
        }
    }
    error(message, error) {
        const timestamp = new Date().toISOString();
        const prefix = `[${timestamp}][${this.context}][ERROR]`;
        if (error) {
            console.error(`${prefix} ${message}`, error);
        }
        else {
            console.error(`${prefix} ${message}`);
        }
    }
}
exports.Logger = Logger;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
!function() {
var exports = __webpack_exports__;
var __webpack_unused_export__;

__webpack_unused_export__ = ({ value: true });
const cache_service_1 = __webpack_require__(279);
const logger_1 = __webpack_require__(530);
const logger = new logger_1.Logger('Background');
const cacheService = new cache_service_1.RentalDataCacheService(logger);
chrome.runtime.onInstalled.addListener(() => {
    console.log('Extension installed');
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'CACHE_GET') {
        cacheService
            .get(request.key)
            .then((result) => sendResponse({ success: true, data: result }))
            .catch((error) => sendResponse({ success: false, error: error.message }));
        return true;
    }
    if (request.type === 'CACHE_SET') {
        cacheService
            .set(request.key, request.data, request.ttl)
            .then(() => sendResponse({ success: true }))
            .catch((error) => sendResponse({ success: false, error: error.message }));
        return true;
    }
    if (request.type === 'CACHE_CLEAR') {
        cacheService
            .clear()
            .then(() => sendResponse({ success: true }))
            .catch((error) => sendResponse({ success: false, error: error.message }));
        return true;
    }
    if (request.type === 'CACHE_CLEANUP') {
        cacheService
            .cleanup()
            .then(() => sendResponse({ success: true }))
            .catch((error) => sendResponse({ success: false, error: error.message }));
        return true;
    }
});

}();
/******/ })()
;